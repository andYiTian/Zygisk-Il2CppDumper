package com.bootdo.testDemo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BinarySearchExample {
    public static void main(String[] args) {
        List<Integer> numbers = new ArrayList<>();
        numbers.add(1);
        numbers.add(3);
        numbers.add(5);
        numbers.add(7);
        numbers.add(9);

        int target = 4;
        int index = Collections.binarySearch(numbers, target);

        if (index >= 0) {
            System.out.println("元素 " + target + " 的索引位置是: " + index);
        } else {
            // 插入位置的计算
            int insertPosition = -(index + 1);
            System.out.println("元素 " + target + " 不在 List 中，可以插入的位置是: " + insertPosition);
        }
    }
}

