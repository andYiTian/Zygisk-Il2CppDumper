package com.bootdo.testDemo;

import com.binance.connector.client.SpotClient;
import com.binance.connector.client.WebSocketApiClient;
import com.binance.connector.client.enums.DefaultUrls;
import com.binance.connector.client.impl.SpotClientImpl;
import com.binance.connector.client.impl.WebSocketApiClientImpl;
import com.binance.connector.client.impl.spot.Market;
import com.binance.connector.client.impl.spot.Trade;
import com.binance.connector.client.impl.websocketapi.WebSocketApiTrade;
import com.binance.connector.client.utils.signaturegenerator.HmacSignatureGenerator;
import com.bootdo.common.utils.JSONUtils;
import com.bootdo.spotgrid.common.Constant;
import com.bootdo.spotgrid.common.websocket.client.ApiWebSocketListener;
import com.bootdo.spotgrid.common.websocket.client.BaseWebsocketClient;
import com.bootdo.spotgrid.common.websocket.client.WebsocketTradeClient;
import com.bootdo.spotgrid.common.websocket.dto.OrderTradeUpdate;
import com.bootdo.spotgrid.common.websocket.dto.UserDataUpdate;
import com.bootdo.spotgrid.common.websocket.event.scheduled.ScheduledTask;
import com.bootdo.spotgrid.service.grid.SIDE;
import com.bootdo.spotgrid.service.grid.SpotGridManager;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.util.concurrent.RateLimiter;
import lombok.SneakyThrows;
import org.apache.tomcat.jni.Local;
import org.json.JSONArray;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.sql.SQLOutput;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class websocketTest {

	
    static String baseAsset = "BNB";
    //static String baseAsset = "ETH";
    static String quoteAsset = "FDUSD";
    static String symbol = baseAsset + quoteAsset;
    
    public static void main(String[] args) {

    	callOrder();
    	
    	queryAccount();
    	//resetOrder();
   

    	//queryPendingOrder();
    	
    	//LinedListTest();
    }
    
    static void LinedListTest() {
    	
    	LinkedList<Integer>  list = Lists.newLinkedList();
    	for(int i=0; i<40; i++) {
    		list.add(i);
    	}
    	System.out.println(list);
    	System.out.println(list.get(20));
    	
    	list.add(40);
    	list.remove(20);
    	System.out.println(list);
    	
    	list.add(41);
    	list.remove(20);
    	System.out.println(list);
    	
//      	list.removeFirst();
//    	System.out.println(list);
//      	
//    	list.add(19, 20);
//    	System.out.println(list);
    	
    	list.removeLast();
    	System.out.println(list);
    	
    	list.add(20, 20);
    	System.out.println(list);
    	
    	
    	list.add(42);
    	list.add(43);
    	list.add(44);
    	list.add(45);
    	
    	System.out.println(list);
    	list.remove(20);
    	list.remove(20);
    	list.remove(20);
    	list.remove(20);
    	
    	System.out.println(list);
    }
    
   
    
    static void callOrder() {
    	

    	SpotClient client = new SpotClientImpl(key, secret,SpotGridManager.URL_HTTP);
    	
    	Trade createTrade = client.createTrade();
 
    	Map<String, Object> parameters = Maps.newHashMap();
    	parameters.put("symbol", symbol);
    	String cancelOpenOrders = createTrade.cancelOpenOrders(parameters);
    	System.out.println(cancelOpenOrders);
    }
    
    static void resetOrder() {
    	
    	SpotClient client = new SpotClientImpl(key, secret,SpotGridManager.URL_HTTP);
    	
    	Trade createTrade = client.createTrade();
    	
       	Map<String, Object> parameters = Maps.newHashMap();
    	parameters.put("symbol", symbol);
    	parameters.put("side", "SELL");
    	parameters.put("type", "MARKET");
        //parameters.put("quantity",free.stripTrailingZeros().toPlainString());
    	parameters.put("quantity","0.010");
    	String newOrder = createTrade.newOrder(parameters);
    	System.out.println(newOrder);
    	
    }
    
    static volatile BigDecimal free=null;
    
    static void queryAccount() {

    	SpotClient client = new SpotClientImpl(key, secret,SpotGridManager.URL_HTTP);
    	
    	Trade createTrade = client.createTrade();
    	String account = createTrade.account(null);
    	
    	JSONObject jsonObject = new JSONObject(account);
    	JSONArray jsonArray = jsonObject.getJSONArray("balances");
    	for (Object object : jsonArray) {
			
    		JSONObject js = (JSONObject)object;
    		String asset = js.getString("asset");
    		if(baseAsset.equals(asset) || quoteAsset.equals(asset)) {
    		
    			System.out.println(js.toString());
    		}
    		if(baseAsset.equals(asset)) {
    			free = js.getBigDecimal("free");
    		}
		}
    }
    
    static void queryPendingOrder() {

    	SpotClient client = new SpotClientImpl(key, secret,SpotGridManager.URL_HTTP);
    	Trade createTrade = client.createTrade();
    	
    	Map<String, Object> parameters = Maps.newHashMap();
    	parameters.put("symbol", symbol);
    	String openOrders = createTrade.getOpenOrders(parameters);
    	System.out.println(openOrders);
    }
    

    
    
    
    
    static String key = "mYn0H2nKJukewG7q1rNKVEVuD2HXRaiuMgU7oILR63EIRhoUvciBBzV94OhSs0HR";
    static String secret = "QRPXNzlSNvUS3r5jRkt1DpHGY9sw8usJcwTV1QkTFoidbaB6Vz2TyVbyFDpdeVq5";
    
   

    @SneakyThrows
    static void jackson(){
        String data = "{\"e\":\"executionReport\",\"E\":1727366979266,\"s\":\"BTCUSDT\",\"c\":\"1727366979228Y8P1my\",\"S\":\"BUY\",\"o\":\"LIMIT_MAKER\",\"f\":\"GTC\",\"q\":\"0.00154000\",\"p\":\"65332.76000000\",\"P\":\"0.00000000\",\"F\":\"0.00000000\",\"g\":-1,\"C\":\"\",\"x\":\"NEW\",\"X\":\"NEW\",\"r\":\"NONE\",\"i\":12083345,\"l\":\"0.00000000\",\"z\":\"0.00000000\",\"L\":\"0.00000000\",\"n\":\"0\",\"N\":null,\"T\":1727366979266,\"t\":-1,\"I\":27233631,\"w\":true,\"m\":false,\"M\":false,\"O\":1727366979266,\"Z\":\"0.00000000\",\"Y\":\"0.00000000\",\"Q\":\"0.00000000\",\"W\":1727366979266,\"V\":\"EXPIRE_MAKER\"}";
        System.out.println(data);

        OrderTradeUpdate orderTradeUpdate = ApiWebSocketListener.MAPPER.readValue(data, OrderTradeUpdate.class);
        System.out.println(orderTradeUpdate);
    }

    static void rateLimitTest(){

        RateLimiter rateLimiter = RateLimiter.create(0.1);

        boolean b = rateLimiter.tryAcquire();
        System.out.println(b);

    }

    @SneakyThrows
    static void tradeTest(){

        Thread.currentThread().sleep(1000*15);

        List<WebsocketTradeClient> list = new ArrayList<>();

        for (int i = 0; i < 1; i++) {

            WebsocketTradeClient tradeClient = new WebsocketTradeClient("BTCUSDT",(msg,data)->{

                System.out.println(data);
            });
            tradeClient.open();
            list.add(tradeClient);
        }

        Thread.currentThread().sleep(1000*15);
        list.forEach(BaseWebsocketClient::close);

    }

    static void solUsdtTest(){

        BigDecimal closePrice = Constant.getClosePrice("SOLUSDT");
        System.out.println(closePrice);

        String clientOrderId = Constant.getClientOrderId();
        System.out.println(clientOrderId);

    }

    @SneakyThrows
    static void tradSolUsdtTest(){

        //149.76000000
        //1727248097286PN1hCe


        String key = "YNav4tmQ8aQkshcFrfXE7t8WxaCFiwKimxYN7vwje5xZ0mIFDf2mPPzz8omAWTpy";
        String secret = "LbglHjlFVecTNVJux1eyUMp7TDk6wpvvwTb4DYtWZ4hOC4JX9plAvU2wqorh8718";

        BigDecimal closePrice = Constant.getClosePrice("SOLUSDT");
        HmacSignatureGenerator signatureGenerator = new HmacSignatureGenerator(secret);

        WebSocketApiClient  apiClient = new WebSocketApiClientImpl(key,signatureGenerator, DefaultUrls.TESTNET_WS_API_URL);
        apiClient.connect((msg)-> System.out.println(msg));
        WebSocketApiTrade trade = apiClient.trade();
        JSONObject parameters = new JSONObject();
//        parameters.put("price","145.76");
//        parameters.put("quantity","1.2");
//        parameters.put("newClientOrderId","1727248097286PN1hCe");
//        trade.newOrder("SOLUSDT","BUY","LIMIT_MAKER",parameters);

        parameters.put("origClientOrderId","1727248097286PN1hCe");
        trade.cancelOrder("SOLUSDT",parameters);
    }

    static void timerTest(){

        Timer timer = new Timer();
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                System.out.println(LocalDateTime.now());
            }
        };
        //timer.schedule(task, 3000L);

        //timer.schedule(task,3000L,2000L);

        System.out.println(LocalDateTime.now());
    }

    static void scheduledTest(){

        ScheduledThreadPoolExecutor executor = new ScheduledThreadPoolExecutor(2);

        //executor.schedule(()-> System.out.println(LocalDateTime.now()),3000L, TimeUnit.MILLISECONDS);

        executor.scheduleWithFixedDelay(()-> System.out.println(LocalDateTime.now()),3000L,0L, TimeUnit.MILLISECONDS);

        System.out.println(LocalDateTime.now());
    }
}
