package com.bootdo.spotgrid.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.bootdo.common.utils.JSONUtils;
import com.bootdo.common.utils.StringUtils;
import com.bootdo.spotgrid.vo.ConfigInfo;
import com.bootdo.spotgrid.vo.ConfigStatus;
import com.bootdo.spotgrid.vo.OtherConfig;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;


/**
 * 现货网格配置
 * 
 * @author dongdogn
 * @email 1992lcg@163.com
 * @date 2024-09-14 15:19:00
 */
@Getter
@Setter
@TableName("spot_grid_config")
public class GridConfigDO implements Serializable {
	private static final long serialVersionUID = 1L;
	
	//
	@TableId(value = "id", type = IdType.AUTO)
	private Long id;
	//账号名称
	private String accountName;
	//基础币种
	private String baseAsset;
	//报价币种
	private String quoteAsset;
	//撤单方式：0-直接撤单，1-不撤单
	private Integer cancelType;
	//网格方案：0-均价，1-均利
	private Integer gridType;
	//方案值：
	private BigDecimal gridValue;
	//最高价格
	private BigDecimal maxPrice;
	//最低价格
	private BigDecimal minPrice;
	//单笔金额
	private BigDecimal singleAmt;
	//区间笔数
	private Integer rangeNum;
	// 最大挂单数
	private Integer entrustNum;
	//状态
	private Integer status;
	//code
	private String code;
	//开始价格
	private BigDecimal startPrice;
	//其他配置
	private String config;
	//盈利配置
	private String statusConfig;
	//
	private LocalDateTime addTime;
	//
	private LocalDateTime updateTime;



	public String symbol(){
		return baseAsset + quoteAsset;
	}


	public OtherConfig selfOtherConfig(){
		return JSONUtils.jsonToBean(config,OtherConfig.class);
	}


	public ConfigStatus selfStatusConfig(){



		ConfigStatus configStatus = JSONUtils.jsonToBean(statusConfig, ConfigStatus.class);

		if(configStatus == null){
			configStatus = new ConfigStatus();
			configStatus.setPairProfit(BigDecimal.ZERO);
			configStatus.setLossProfit(BigDecimal.ZERO);
			configStatus.setTotalProfit(BigDecimal.ZERO);
			configStatus.setConfigInfo(new ConfigInfo());
			return configStatus;
		}

		if(configStatus.getPairProfit() == null){
			configStatus.setPairProfit(BigDecimal.ZERO);
		}
		if(configStatus.getLossProfit() == null){
			configStatus.setLossProfit(BigDecimal.ZERO);
		}
		if(configStatus.getTotalProfit() == null){
			configStatus.setTotalProfit(BigDecimal.ZERO);
		}
		if(configStatus.getConfigInfo() == null) {
			configStatus.setConfigInfo(new ConfigInfo());
		}

		return configStatus;
	}
}
