package com.bootdo.spotgrid.common.websocket.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@JsonIgnoreProperties(ignoreUnknown = true)
@Setter
@Getter
public class BookTicker {

    @JsonProperty("u")
    private Long updateId;
    @JsonProperty("s")
    private String symbol;
    @JsonProperty("b")
    private BigDecimal buyPrice;
    @JsonProperty("B")
    private BigDecimal buyQuantity;
    @JsonProperty("a")
    private BigDecimal sellPrice;
    @JsonProperty("A")
    private BigDecimal sellQuantity;

}
