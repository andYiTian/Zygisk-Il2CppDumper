package com.bootdo.spotgrid.common.websocket.dto;

import com.bootdo.spotgrid.common.websocket.serialization.AssetBalanceDeserializer;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.Data;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class AccountUpdate {

    @JsonProperty("e")
    String eventType;

    @JsonProperty("E")
    Long eventTime;

    @JsonProperty("B")
    @JsonDeserialize(contentUsing = AssetBalanceDeserializer.class)
    List<AssetBalance> balances;
}
