package com.bootdo.spotgrid.service.impl;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.bootdo.spotgrid.common.Constant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.bootdo.spotgrid.dao.ApiTrackDao;
import com.bootdo.spotgrid.domain.ApiTrackDO;
import com.bootdo.spotgrid.service.ApiTrackService;
import reactor.util.function.Tuple3;
import reactor.util.function.Tuples;


@Service
@Slf4j
public class ApiTrackServiceImpl implements ApiTrackService {
	@Autowired
	private ApiTrackDao apiTrackDao;
	
	@Override
	public ApiTrackDO get(Long id){
		return apiTrackDao.selectById(id);
	}

	
	@Override
	public int save(ApiTrackDO apiTrack){
		return apiTrackDao.insert(apiTrack);
	}
	
	@Override
	public int update(ApiTrackDO apiTrack){
		return apiTrackDao.updateById(apiTrack);
	}
	
	@Override
	public int remove(Long id){
		return apiTrackDao.deleteById(id);
	}
	
	@Override
	public int batchRemove(Long[] ids){
		return apiTrackDao.deleteBatchIds(Stream.of(ids).collect(Collectors.toList()));
	}

	@Override
	public Map<String,List<ApiTrackDO>> getByClient(List<String> clientIds){

		List<ApiTrackDO> apiTrackDOS = apiTrackDao.selectList(Wrappers.lambdaQuery(ApiTrackDO.class).in(ApiTrackDO::getClientId, clientIds));

		return apiTrackDOS.stream().collect(Collectors.groupingBy(ApiTrackDO::getClientId));
	}

	@Override
	public List<ApiTrackDO> getByClient(String clientId){
		return apiTrackDao.selectList(Wrappers.lambdaQuery(ApiTrackDO.class).eq(ApiTrackDO::getClientId, clientId));
	}

	@Override
	public ApiTrackDO getByClientNew(String clientId) {

		List<ApiTrackDO> list = apiTrackDao.selectList(Wrappers.lambdaQuery(ApiTrackDO.class).eq(ApiTrackDO::getClientId, clientId));
		log.info("getByClientNew clientId:{},ids:{}",clientId,list.stream().map(ApiTrackDO::getId).collect(Collectors.toList()));
		return list.stream().filter(self -> Constant.orderNew(self.getOrderStatus())).findFirst().orElse(null);
	}


	@Override
	public ApiTrackDO getByClientCanceled(String clientId) {
		List<ApiTrackDO> list = apiTrackDao.selectList(Wrappers.lambdaQuery(ApiTrackDO.class).eq(ApiTrackDO::getClientId, clientId));
		log.info("getByClientCanceled clientId:{},ids:{}",clientId,list.stream().map(ApiTrackDO::getId).collect(Collectors.toList()));
		return list.stream().filter(self -> Constant.orderCancel(self.getOrderStatus())).findFirst().orElse(null);
	}

	@Override
	public ApiTrackDO getByClientFilled(String clientId) {
		List<ApiTrackDO> list = apiTrackDao.selectList(Wrappers.lambdaQuery(ApiTrackDO.class).eq(ApiTrackDO::getClientId, clientId));
		log.info("getByClientFilled clientId:{},ids:{}",clientId,list.stream().map(ApiTrackDO::getId).collect(Collectors.toList()));
		return list.stream().filter(self -> Constant.orderFilled(self.getOrderStatus())).findFirst().orElse(null);
	}

	/**
	 * 剩余未成交数量
	 */
	@Override
	public Tuple3<BigDecimal, BigDecimal, BigDecimal> getByCanceledNumber(String clientId) {
		List<ApiTrackDO> list = apiTrackDao.selectList(Wrappers.lambdaQuery(ApiTrackDO.class).eq(ApiTrackDO::getClientId, clientId));
		ApiTrackDO entrust = list.stream().filter(self -> Constant.orderNew(self.getOrderStatus())).findFirst().get();
		BigDecimal tradeNumber = list.stream()
				.filter(self -> "TRADE".equals(self.getExecutionType()))
				.map(ApiTrackDO::getQuantityLastFilledTrade)
				.reduce(BigDecimal.ZERO, BigDecimal::add);

		BigDecimal subtract = entrust.getOrgiginalQuantity().subtract(tradeNumber);
		log.info("getByCanceledNumber clientId:{}, entrustNum:{} tradeNum:{} ids:{}",clientId, entrust.getOrgiginalQuantity(), tradeNumber, list.stream().map(ApiTrackDO::getId).collect(Collectors.toList()));

		ApiTrackDO maxId = list.stream().max(Comparator.comparing(ApiTrackDO::getId)).get();

		log.info("maxId:{}", JSON.toJSONString(maxId));

		// 未成交,已成交,均价
		return Tuples.of(subtract, tradeNumber, maxId.realAvgPrice());
	}

	@Override
	public ApiTrackDao getApiTrackDao() {
		return apiTrackDao;
	}
}
