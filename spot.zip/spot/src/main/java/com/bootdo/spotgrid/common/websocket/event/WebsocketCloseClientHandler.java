package com.bootdo.spotgrid.common.websocket.event;

import com.bootdo.spotgrid.common.websocket.callback.WebsocketInterceptorCallback;
import com.bootdo.spotgrid.common.websocket.client.WebsocketClient;

/**
 * Will close the client after {@link WebsocketClientConfiguration#closeAfter}
 */
public class WebsocketCloseClientHandler extends BaseWebsocketEventHandler {
    /**
     * @param websocketClient Websocket client.
     * @param callback        Callback.
     */
    public WebsocketCloseClientHandler(WebsocketClient websocketClient, WebsocketInterceptorCallback<?> callback) {
        super(websocketClient, callback, "Client not closing", "Disconnected");
    }

    public void run() {
        cancel();
        disconnect(websocketClient.getConfiguration().getCloseAfter());
    }
}
