package com.bootdo.spotgrid.common.websocket.dto;

import com.bootdo.common.utils.StringUtils;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class OrderTradeUpdate {
    @JsonProperty("e") String eventType;
    @JsonProperty("E") LocalDateTime eventTime;
    @JsonProperty("s") String symbol;
    @JsonProperty("c") String newClientOrderId;

    public String getNewClientOrderId() {
        return StringUtils.isEmpty(cancelClientOrderId) ? newClientOrderId : cancelClientOrderId;
    }

    @JsonProperty("C") String cancelClientOrderId;
    @JsonProperty("S") String side;
    @JsonProperty("o") String type;
    @JsonProperty("f") TimeInForce timeInForce;
    @JsonProperty("q")
    BigDecimal originalQuantity;
    @JsonProperty("p") BigDecimal price;
    @JsonProperty("x") String executionType;
    @JsonProperty("X") String orderStatus;
    @JsonProperty("r") String orderRejectReason;
    @JsonProperty("i") Long orderId;
    @JsonProperty("l") BigDecimal quantityLastFilledTrade;
    @JsonProperty("z") BigDecimal accumulatedQuantity;
    @JsonProperty("L") BigDecimal priceOfLastFilledTrade;
    @JsonProperty("n") BigDecimal commission;
    @JsonProperty("N") String commissionAsset;
    @JsonProperty("T")
    LocalDateTime orderTradeTime;
    @JsonProperty("t") Long tradeId;
    @JsonProperty("w")
    String orderBook;
    @JsonProperty("m")
    String pending;
    @JsonProperty("O") LocalDateTime orderCreationTime;
    @JsonProperty("Z") BigDecimal cumulativeQuoteQuantity;
    @JsonProperty("Y") BigDecimal lastQuoteQuantity;
    @JsonProperty("Q") BigDecimal quoteOrderQuantity;
}
