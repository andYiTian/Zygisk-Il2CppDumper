package com.bootdo.spotgrid.common.websocket.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class BalanceUpdate {

    @JsonProperty("e") String eventType;
    @JsonProperty("E") Long eventTime;
    @JsonProperty("a") String asset;
    @JsonProperty("d") String balanceDelta;
    @JsonProperty("T") Long clearTime;
}
