package com.bootdo.spotgrid.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bootdo.spotgrid.domain.AccountDO;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

/**
 * 现货账号
 * @author dongdogn
 * @email 1992lcg@163.com
 * @date 2024-09-14 14:02:27
 */
@Mapper
public interface AccountDao extends BaseMapper<AccountDO> {

}
