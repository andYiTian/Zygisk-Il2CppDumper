package com.bootdo.spotgrid.controller;

import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.bootdo.spotgrid.dao.ApiTrackDao;
import com.bootdo.spotgrid.domain.AccountDO;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bootdo.spotgrid.domain.ApiTrackDO;
import com.bootdo.spotgrid.service.ApiTrackService;
import com.bootdo.common.utils.PageUtils;
import com.bootdo.common.utils.Query;
import com.bootdo.common.utils.R;

/**
 * 现货交易详情
 * 
 * @author dongdong
 * @email 111
 * @date 2024-09-18 23:07:06
 */
 
@Controller
@RequestMapping("/spotgrid/apiTrack")
public class ApiTrackController {
	@Autowired
	private ApiTrackService apiTrackService;

	@Autowired
	private ApiTrackDao trackDao;
	
	@GetMapping()
	@RequiresPermissions("spotgrid:apiTrack:apiTrack")
	String ApiTrack(){
	    return "spotgrid/apiTrack/apiTrack";
	}
	
	@ResponseBody
	@GetMapping("/list")
	@RequiresPermissions("spotgrid:apiTrack:apiTrack")
	public PageUtils list(@RequestParam Map<String, Object> params){
		//查询列表数据
		Query query = new Query(params);
		IPage<ApiTrackDO> page = trackDao.selectPage(Page.of(query.getPage(), query.getLimit()),null);
		return PageUtils.returnPage(page);
	}
	
	@GetMapping("/add")
	@RequiresPermissions("spotgrid:apiTrack:add")
	String add(){
	    return "spotgrid/apiTrack/add";
	}

	@GetMapping("/edit/{id}")
	@RequiresPermissions("spotgrid:apiTrack:edit")
	String edit(@PathVariable("id") Long id,Model model){
		ApiTrackDO apiTrack = apiTrackService.get(id);
		model.addAttribute("apiTrack", apiTrack);
	    return "spotgrid/apiTrack/edit";
	}
	
	/**
	 * 保存
	 */
	@ResponseBody
	@PostMapping("/save")
	@RequiresPermissions("spotgrid:apiTrack:add")
	public R save( ApiTrackDO apiTrack){
		if(apiTrackService.save(apiTrack)>0){
			return R.ok();
		}
		return R.error();
	}
	/**
	 * 修改
	 */
	@ResponseBody
	@RequestMapping("/update")
	@RequiresPermissions("spotgrid:apiTrack:edit")
	public R update( ApiTrackDO apiTrack){
		apiTrackService.update(apiTrack);
		return R.ok();
	}
	
	/**
	 * 删除
	 */
	@PostMapping( "/remove")
	@ResponseBody
	@RequiresPermissions("spotgrid:apiTrack:remove")
	public R remove( Long id){
		if(apiTrackService.remove(id)>0){
		return R.ok();
		}
		return R.error();
	}
	
	/**
	 * 删除
	 */
	@PostMapping( "/batchRemove")
	@ResponseBody
	@RequiresPermissions("spotgrid:apiTrack:batchRemove")
	public R remove(@RequestParam("ids[]") Long[] ids){
		apiTrackService.batchRemove(ids);
		return R.ok();
	}
	
}
