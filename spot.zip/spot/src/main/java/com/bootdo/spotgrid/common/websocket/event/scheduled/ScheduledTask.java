package com.bootdo.spotgrid.common.websocket.event.scheduled;

/** A scheduled task called by a {@link ScheduledEvent} as a lambda */
public interface ScheduledTask {
    /** Lambda method */
    void call();
}