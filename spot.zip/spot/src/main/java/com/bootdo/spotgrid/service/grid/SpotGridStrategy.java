package com.bootdo.spotgrid.service.grid;

import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

/**
 * 现货网格策略
 */
@Slf4j
public class SpotGridStrategy extends Thread {

    private AtomicReference<BigDecimal> buyPriceRef = new AtomicReference<>();
    private AtomicReference<BigDecimal> sellPriceRef = new AtomicReference<>();

    public void bookTicker(BigDecimal buyPrice, BigDecimal sellPrice){

        if(buyPriceRef.get() == null || buyPriceRef.get().compareTo(buyPrice) != 0){
            buyPriceRef.set(buyPrice);

            gridOrder.getCurrentPriceLine(buyPrice);
        }
    }





    /** 网格价格线 */
    private final List<SpotGridOrder.PriceLine> lines;

    private final int lineSize;

    private final SpotGridOrder gridOrder;

    public SpotGridStrategy(SpotGridOrder gridOrder) {

        this.gridOrder = gridOrder;
        this.lines = gridOrder.generateLine();
        this.lineSize = lines.size();

    }
}
