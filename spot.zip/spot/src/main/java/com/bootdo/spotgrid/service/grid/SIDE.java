package com.bootdo.spotgrid.service.grid;

public enum SIDE{
    BUY,SELL,ALL
}
