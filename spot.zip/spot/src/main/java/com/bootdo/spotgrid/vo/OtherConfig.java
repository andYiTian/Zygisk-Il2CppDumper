package com.bootdo.spotgrid.vo;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * 其他相应配置
 */
@Getter
@Setter
public class OtherConfig {

    /** 首单跌幅 */
    private BigDecimal headOrderFall;

    /** 补偿 */
    private BigDecimal compensate;
}
