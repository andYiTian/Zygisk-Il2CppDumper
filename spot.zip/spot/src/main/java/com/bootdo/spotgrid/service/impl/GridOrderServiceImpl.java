package com.bootdo.spotgrid.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.bootdo.spotgrid.common.Constant;
import com.bootdo.spotgrid.domain.GridConfigDO;
import com.bootdo.spotgrid.service.grid.SIDE;
import com.google.common.collect.Maps;
import com.google.common.collect.Table;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.bootdo.spotgrid.dao.GridOrderDao;
import com.bootdo.spotgrid.domain.GridOrderDO;
import com.bootdo.spotgrid.service.GridOrderService;



@Service
public class GridOrderServiceImpl implements GridOrderService {

	@Autowired
	private GridOrderDao gridOrderDao;

	@Override
	public GridOrderDO get(Long id){
		return gridOrderDao.selectById(id);
	}

	@Override
	public GridOrderDO getByClientId(String clientId){
		return gridOrderDao.selectOne(Wrappers.lambdaQuery(GridOrderDO.class).eq(GridOrderDO::getClientId, clientId));
	}
	@Override
	public List<GridOrderDO> getOrdersByWait(GridConfigDO configDO){
		return gridOrderDao.selectList(Wrappers.lambdaQuery(GridOrderDO.class)
				.eq(GridOrderDO::getConfigId,configDO.getId())
				.eq(GridOrderDO::getCode,configDO.getCode())
				.eq(GridOrderDO::getSymbol,configDO.symbol())
				.in(GridOrderDO::getStatus, Constant.Order_Local,Constant.Order_NEW));
	}


	@Override
	public GridOrderDao getGridOrderDao() {
		return gridOrderDao;
	}

	@Override
	public int save(GridOrderDO gridOrder){
		return gridOrderDao.insert(gridOrder);
	}
	
	@Override
	public int update(GridOrderDO gridOrder){
		return gridOrderDao.updateById(gridOrder);
	}
	
	@Override
	public int remove(Long id){
		return gridOrderDao.deleteById(id);
	}
	
	@Override
	public int batchRemove(Long[] ids){
		return gridOrderDao.deleteBatchIds(Stream.of(ids).collect(Collectors.toList()));
	}

	@Override
	public GridOrderDO getByTypePrice(GridConfigDO configDO,BigDecimal price, SIDE side) {

		return gridOrderDao.selectOne(Wrappers.lambdaQuery(GridOrderDO.class)
				.eq(GridOrderDO::getConfigId,configDO.getId())
				.eq(GridOrderDO::getCode,configDO.getCode())
				.eq(GridOrderDO::getSymbol,configDO.symbol())
				.eq(GridOrderDO::getStatus,Constant.Order_NEW)
				.eq(GridOrderDO::getTrendType,side.toString())
				.eq(GridOrderDO::getEntrustPrice,price));
	}

	@Override
	public List<GridOrderDO> getLoad(GridConfigDO configDO) {

		return gridOrderDao.selectList(Wrappers.lambdaQuery(GridOrderDO.class)
				.eq(GridOrderDO::getConfigId,configDO.getId())
				.eq(GridOrderDO::getCode,configDO.getCode())
				.eq(GridOrderDO::getSymbol,configDO.symbol())
				.in(GridOrderDO::getStatus, Constant.Order_Local,Constant.Order_NEW));
	}

	@Override
	public List<GridOrderDO> batchBuyByIds(List<Long> ids) {


		List<GridOrderDO> gridOrderDOS = gridOrderDao.selectList(Wrappers.lambdaQuery(GridOrderDO.class)
				.select(GridOrderDO::getId, GridOrderDO::getPairId)
				.in(GridOrderDO::getId, ids));

		List<Long> buyIds = gridOrderDOS.stream().map(GridOrderDO::getPairId).collect(Collectors.toList());

		return gridOrderDao.selectBatchIds(buyIds);
	}

	public GridOrderDO getSellOrderByPairId(GridOrderDO buyOrder){

		return gridOrderDao.selectOne(Wrappers.lambdaQuery(GridOrderDO.class)
				.eq(GridOrderDO::getPairId,buyOrder.getOrderId())
				.eq(GridOrderDO::getTrendType,Constant.SELL)
				.eq(GridOrderDO::getStatus,Constant.Order_NEW)
		);
	}
}
