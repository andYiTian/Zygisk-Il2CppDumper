package com.bootdo.spotgrid.common;

import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;

import java.util.concurrent.ThreadFactory;

@Slf4j
public class CustomThreadFactory implements ThreadFactory {

    public static final CustomThreadFactory instance = new CustomThreadFactory();

    private CustomThreadFactory() {}

    @Override
    public Thread newThread(@NotNull Runnable r) {
        return new CustomThread(r);
    }

    static class CustomThread extends Thread {

        public CustomThread(Runnable r) {
            super(r);
        }

        @Override
        public void run() {
            try{
                super.run();
            } catch (Exception e) {
                log.error("CustomThread-run-Exception\n",e);
            }
        }
    }
}
