package com.bootdo.spotgrid.common;

import cn.hutool.core.util.RandomUtil;
import com.binance.connector.client.SpotClient;
import com.binance.connector.client.impl.SpotClientImpl;
import com.binance.connector.client.impl.spot.Market;
import com.google.common.collect.Maps;
import org.json.JSONObject;
import org.slf4j.MDC;

import java.math.BigDecimal;
import java.util.Map;

public interface Constant {

    Integer YES = 1, NO = 0;

    Integer STOP_CANCEL = 2;

    /**
     * 平台#类型#币种
     */
    String TRACID = "tracId";
    /**
     * 运行id
     */
    String RUNID = "runId";

    String SELL = "SELL";

    String BUY = "BUY";


    static void setMDC(String TRACID, String RUNID) {
        MDC.put(Constant.TRACID, TRACID);
        MDC.put(Constant.RUNID, RUNID);
    }

    static void setMDC(String TRACID) {
        MDC.put(Constant.TRACID, TRACID);
        MDC.put(Constant.RUNID, "0");
    }

    static String getClientOrderId() {
        return System.currentTimeMillis()  + RandomUtil.randomString(6);
    }

    String Order_Local = "LOCAL";

    String Order_NEW = "NEW";

    String Order_Cancel = "CANCELED";

    String Order_Filled = "FILLED";

    String Order_Loss = "LOSS";
    
    String Order_Load = "shelve";
    
    String Blank = "";

    static boolean orderNew(String status){
        return Order_NEW.equals(status);
    }
    static boolean orderFilled(String status){
        return Order_Filled.equals(status);
    }
    static boolean orderCancel(String status){
        return "CANCELED".equals(status) || "REJECTED".equals(status) || "EXPIRED".equals(status) || "EXPIRED_IN_MATCH".equals(status);
    }

    SpotClient spotClient = new SpotClientImpl();

    Market market = spotClient.createMarket();

    static BigDecimal getClosePrice(String symbol){
        Map<String, Object> parameters = Maps.newHashMap();
        parameters.put("symbol", symbol);
        String s = market.tickerSymbol(parameters);
        return new JSONObject(s).getBigDecimal("price");
    }
}
