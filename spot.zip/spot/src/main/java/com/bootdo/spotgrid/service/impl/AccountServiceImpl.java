package com.bootdo.spotgrid.service.impl;

import com.bootdo.spotgrid.service.account.SpotAccountCheck;
import org.springframework.stereotype.Service;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.bootdo.spotgrid.dao.AccountDao;
import com.bootdo.spotgrid.domain.AccountDO;
import com.bootdo.spotgrid.service.AccountService;
import org.springframework.util.Assert;


@Service
public class AccountServiceImpl implements AccountService {
	final AccountDao accountDao;

	final SpotAccountCheck accountCheck;

    public AccountServiceImpl(AccountDao accountDao, SpotAccountCheck accountCheck) {
        this.accountDao = accountDao;
        this.accountCheck = accountCheck;
    }

    @Override
	public AccountDO get(Long id){
		return accountDao.selectById(id);
	}
	
	@Override
	public int save(AccountDO account){

		Assert.isTrue(accountCheck.accountCheck(account),"api没有现货交易权限");
		return accountDao.insert(account);
	}
	
	@Override
	public int update(AccountDO account){

		Assert.isTrue(accountCheck.accountCheck(account),"api没有现货交易权限");
		return accountDao.updateById(account);
	}
	
	@Override
	public int remove(Long id){
		return accountDao.deleteById(id);
	}
	
	@Override
	public int batchRemove(Long[] ids){
		return accountDao.deleteBatchIds(Stream.of(ids).collect(Collectors.toList()));
	}

	@Override
	public AccountDao getAccountDao() {
		return accountDao;
	}
}
