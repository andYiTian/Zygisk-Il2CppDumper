package com.bootdo.spotgrid.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDateTime;


/**
 * 现货账号
 * 
 * @author dongdogn
 * @email 1992lcg@163.com
 * @date 2024-09-14 14:02:27
 */
@Getter
@Setter
@TableName("spot_account")
public class AccountDO implements Serializable {
	private static final long serialVersionUID = 1L;
	
	//
	@TableId(value = "id", type = IdType.AUTO)
	private Long id;
	//api名称
	private String accountName;
	//api-key
	private String accountKey;
	//api密钥
	private String accountSecret;
	//
	private LocalDateTime addTime;
	//
	private LocalDateTime updateTime;


}
