package com.bootdo.spotgrid.service.grid;


import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.RandomUtil;
import com.alibaba.fastjson2.JSON;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.binance.connector.client.WebSocketApiClient;
import com.binance.connector.client.impl.WebSocketApiClientImpl;
import com.binance.connector.client.impl.spot.Market;
import com.binance.connector.client.impl.websocketapi.WebSocketApiTrade;
import com.binance.connector.client.utils.signaturegenerator.HmacSignatureGenerator;
import com.bootdo.common.utils.JSONUtils;
import com.bootdo.common.utils.StringUtils;
import com.bootdo.spotgrid.common.Constant;
import com.bootdo.spotgrid.dao.AccountDao;
import com.bootdo.spotgrid.dao.GridOrderDao;
import com.bootdo.spotgrid.dao.GridRangeDao;
import com.bootdo.spotgrid.domain.*;
import com.bootdo.spotgrid.service.ApiTrackService;
import com.bootdo.spotgrid.service.GridConfigService;
import com.bootdo.spotgrid.service.GridOrderService;
import com.bootdo.spotgrid.vo.ConfigInfo;
import com.bootdo.spotgrid.vo.ConfigStatus;
import com.bootdo.spotgrid.vo.OtherConfig;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Queues;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.LockSupport;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

@Slf4j
public class SpotGridOrder extends Thread{

    final Long configId;

    final String symbol;

    final GridConfigDO configDO;

    final WebSocketInfo webSocketInfo = new WebSocketInfo();


    WebSocketApiClient apiClient;

    WebSocketApiTrade trade;

    final Thread master = this;

    final ApiTrackService apiTrackService;

    final GridOrderService orderService;

    final GridConfigService configService;

    @Getter
    final String mdc;

    /// 网格订单
    private final SymbolAccuracy symbolAccuracy;

    private final OtherConfig otherConfig;

    @Getter
    private final ConfigStatus configStatus;

    /** 网格价格线 */
    private final List<PriceLine> lines;

    private final int lineSize;

    private final Map<BigDecimal, PriceLine> buyLines = Maps.newHashMap();
    private final Map<BigDecimal, PriceLine> sellLines = Maps.newHashMap();

    public List<GridOrderDO> getBuyCompleteRange(){
        return buyCompleteRange;
    }

    public List<GridOrderDO> getSellCompleteRange(){
        return sellCompleteRange;
    }

    /** 起点设置 */
    private final Lock pointLock = new ReentrantLock();
    /** 买单成功区间 */
    private final LinkedList<GridOrderDO> buyCompleteRange = Lists.newLinkedList();
    /** 买单预备区间 */
    private final Map<String,GridOrderDO> buyPrepareRange = Maps.newHashMap();
    /** 买单失败 */
    private final List<GridOrderDO> buyFails = Lists.newArrayList();

    /** 卖单成功区间 */
    private final LinkedList<GridOrderDO> sellCompleteRange = Lists.newLinkedList();
    /** 卖单预备区间 */
    private final Map<String,GridOrderDO> sellPrepareRange = Maps.newHashMap();
    /** 卖单失败 */
    private final List<GridOrderDO> sellFails = Lists.newArrayList();

    /** 卖单最大挂单数 */
    static final int Sell_Size = 40;
    
    private final Map<Integer, RangeProDO> rangeProMap;

    private final int minRange,maxRange;

    ///
    private final AtomicBoolean running = new AtomicBoolean(true);

    public boolean getRunning(){
        return running.get();
    }
    public void runningStop(){
        running.set(false);
    }

    public void cancelAllStop(){
        running.set(false);

        while(!buyCompleteRange.isEmpty()){
            GridOrderDO gridOrderDO = buyCompleteRange.removeFirst();
            realCancel(gridOrderDO);
        }
        while(!sellCompleteRange.isEmpty()){
            GridOrderDO gridOrderDO = sellCompleteRange.removeLast();
            realCancel(gridOrderDO);
        }
        
        clearConfigStatus();
    }

    public SpotGridOrder(Long configId, ExecutorService executorService, ApiTrackService apiTrackService, GridOrderService orderService, GridConfigService configService, GridRangeDao rangeDao, AccountDao accountDao) {
        this.configId = configId;
        this.configService = configService;
        this.configDO = configService.get(configId);
        this.otherConfig = configDO.selfOtherConfig();
        this.configStatus = configDO.selfStatusConfig();
        this.symbol = configDO.getBaseAsset() + configDO.getQuoteAsset();
        this.symbolAccuracy = getSymbolAccuracyInfo(symbol);
        this.orderService = orderService;
        this.apiTrackService = apiTrackService;
        this.lines = generateLine();
        this.lineSize = lines.size();
        this.rangeProMap = rangeDao.selectList(null).stream().collect(Collectors.toMap(RangeProDO::getRangeIndex, Function.identity()));
        this.minRange = rangeProMap.keySet().stream().min(Integer::compare).get();
        this.maxRange = rangeProMap.keySet().stream().max(Integer::compare).get();
        this.executorService = executorService;

        setName(configDO.getAccountName() + "-" + symbol);
        this.mdc = "order-grid-" + getName();

        if(StringUtils.isBlank(configDO.getCode())){
            String randomString = RandomUtil.randomString(6);
            configDO.setCode(randomString);

            GridConfigDO update = new GridConfigDO();
            update.setCode(randomString);
            update.setId(configId);
            configService.update(update);
        }

        AccountDO account = accountDao.selectOne(Wrappers.lambdaQuery(AccountDO.class).eq(AccountDO::getAccountName, configDO.getAccountName()));
        HmacSignatureGenerator signatureGenerator = new HmacSignatureGenerator(account.getAccountSecret());
        apiClient = new WebSocketApiClientImpl(account.getAccountKey(),signatureGenerator,SpotGridManager.URL_ORDER_WEBSOCKET);

    }

    /** 网格头尾单处理*/
    private final ExecutorService executorService;

    /**
     * 直撤 卖单全撤 等待完成 合并卖单
     * <p>
     * 首单撤单 等待 市价卖出
     */
    private final LinkedBlockingDeque<Runnable> task = Queues.newLinkedBlockingDeque();

    @Override
    public void run() {

        Constant.setMDC(mdc);

        connect();

        while(running.get()){

            try {
            	if(!task.isEmpty()) {
            		while(!task.isEmpty()) {
            			task.pollLast().run();
            		}
            		continue;
            	}
                if(webSocketStatus()){
                    gridRun();
                }
            } catch (Exception e) {
                log.error("run-exit",e);
                runningStop();
                return;
            } finally {
                // 暂停5秒
                LockSupport.parkNanos(master,1000 * 1000L * 1000L * 5);
            }
        }
    }

    private void gridRun(){

        if(!webSocketInfo.openFlag){
            return;
        }

        if(sellCompleteRange.isEmpty() && buyPrepareRange.isEmpty() && !buyCompleteRange.isEmpty()){


            if(!pointLock.tryLock()){
                return;
            }
            try {
                log.info("gridRun sellRange.isEmpty");

                PriceLine priceLine = getPriceLine(buyCompleteRange.getFirst());
                int pre = priceLine.index + 1;
                if(pre < lineSize){

                    BigDecimal closePrice = Constant.getClosePrice(symbol);
                    PriceLine tmp = lines.get(pre);
                    boolean flag = tmp.buyPrice.compareTo(closePrice) <= 0;
                    log.info(" first.index:{} buyPrice:{} tmp.index:{} tmp.buyPrice:{} closePrice:{} flag:{}",priceLine.index,priceLine.buyPrice,tmp.index,tmp.buyPrice,closePrice,flag);
                    if(flag){

                        // first
                        openBuy(lines.get(pre));
                        realCancel(buyCompleteRange.getLast());
                    }
                }
            } finally {
                pointLock.unlock();
            }
        }
    }



    public void init(){

        BigDecimal startPrice = Constant.getClosePrice(symbol).setScale(symbolAccuracy.priceAccuracy(), RoundingMode.DOWN);
        
        PriceLine currentPriceLine = getCurrentPriceLine(startPrice);
        if(currentPriceLine == null){
            log.error("获取网格line null startPrice：{}", startPrice);
            throw new RuntimeException("获取网格line null startPrice:" + startPrice);
        }
        init(currentPriceLine);
    }

    private void init(PriceLine currentPriceLine){

        log.info("init");

        for(int i = 0; i < configDO.getEntrustNum(); i++){

            int next = currentPriceLine.index - i;
            if(next >= 0){

                // last
                openBuy(lines.get(next));
            }
        }

    }

    private boolean load(){

        List<GridOrderDO> gridOrders = orderService.getLoad(configDO);

        boolean empty = gridOrders.isEmpty();

        log.info("load empty:{}",empty);
        if(empty){
            return false;
        }

        log.info("load gridOrders.size:{}", gridOrders.size());
        // 价格 低到高
        gridOrders.stream()
                .filter(self -> SIDE.BUY.toString().equals(self.getTrendType()))
                .sorted(Comparator.comparing(GridOrderDO::getEntrustPrice))
                .forEach(buyCompleteRange::addFirst);

        // 价格 低到高
        gridOrders.stream()
                .filter(self -> SIDE.SELL.toString().equals(self.getTrendType()))
                .sorted(Comparator.comparing(GridOrderDO::getEntrustPrice))
                .forEach(sellCompleteRange::addFirst);

        rangePin(configDO.getStartPrice());

        return true;
    }


    public void orderFilled(GridOrderDO gridOrder){

        if(!running.get()){
            return;
        }

        // 买单成交  价格下跌
        if(Constant.BUY.equals(gridOrder.getTrendType())){
            buyFilled(gridOrder);
            currentRange();
        }

        // 卖单成交  价格上涨  计算盈利   
        if(Constant.SELL.equals(gridOrder.getTrendType())){
            sellFilled(gridOrder);
            checkout(gridOrder);
        }

        rangeMaintain(gridOrder);

        strategyLogic();
    }


    /** 买单成交 价格下跌 */
    public void buyFilled(GridOrderDO gridOrder){

        rangePin(gridOrder.getEntrustPrice());

        GridOrderDO first = buyCompleteRange.getFirst();
        if(!first.getId().equals(gridOrder.getId())){
            log.error("buyFilled buyRange.first id:{} 和入参 gridOrder.id:{} 不相同", first.getId(), gridOrder.getId());
        }

        //sell-last add
        openSell(gridOrder);
        // buy-first del
        buyCompleteRange.removeFirst();
        // buy-last add
        GridOrderDO last = buyCompleteRange.getLast();
        PriceLine priceLine = getPriceLine(last);
        int newLast = priceLine.index - 1;
        if(newLast >= 0){

            // last
            openBuy(lines.get(newLast));
        }
    }

    /**
     * 当前区间信息
     */
    private void currentRange() {
    	
    	if(buyCompleteRange.isEmpty()) {
    		return;
    	}
    	GridOrderDO first = buyCompleteRange.getFirst();
    	PriceLine priceLine = getPriceLine(first);
    	
        ConfigInfo configInfo = configStatus.getConfigInfo();
        configInfo.setRangeIndex(priceLine.range);
        
    	lines.stream().filter(self->self.range == priceLine.range).map(self->self.buyPrice).max(BigDecimal::compareTo)
    	.ifPresent(configInfo::setRangeStart);
    	
    	lines.stream().filter(self->self.range == priceLine.range).map(self->self.buyPrice).min(BigDecimal::compareTo)
    	.ifPresent(configInfo::setRangeEnd);
    }

    /**
     * 买单首次成交 没有卖单 use || load加载
     * @param startPrice
     */
    private void rangePin(BigDecimal startPrice){

        if(startPrice == null || !sellCompleteRange.isEmpty() || !sellPrepareRange.isEmpty()){
            return;
        }

        log.info("rangePin startPrice:{}", startPrice);

        // 区间确定 起始价格确定

        GridConfigDO update = new GridConfigDO();
        update.setStartPrice(startPrice);
        update.setId(configId);
        configService.update(update);

        ConfigInfo configInfo = configStatus.getConfigInfo();
        configInfo.setStartPrice(startPrice);

        PriceLine currentPriceLine = getCurrentPriceLine(startPrice);
        int rangeNum = configDO.getRangeNum();

        lines.forEach(self->self.range=0);

        int size = 1;
        for(int i = currentPriceLine.index; i >= 0 ; i--){

            lines.get(i).range = ((size-1)/rangeNum) + 1;
            size++;
        }

/*        size = -1;
        for(int i = currentPriceLine.index + 1; i < lines.size() ; i++){

            lines.get(i).range = ((Math.abs(size)-1)/rangeNum) + 1;
            size--;
        }*/

    }

    static final String First_Loss = "first_loss";

    /** 卖单成交 价格上涨 */
    public void sellFilled(GridOrderDO gridOrder){

        if(First_Loss.equals(gridOrder.getType())){
            sellCompleteRange.removeFirst();
            return;
        }

        GridOrderDO lastOrder = sellCompleteRange.removeLast();
        if(!lastOrder.getId().equals(gridOrder.getId())){
            log.error("sellFilled sellRange.last id:{} 和入参 gridOrder.id:{} 不相同", lastOrder.getId(), gridOrder.getId());
        }

        // 合并单成交  重新开始
        if(gridOrder.isMerge()){
        	
        	log.info("合并单成交");
        	LinkedList<GridOrderDO> beforeCopy = Lists.newLinkedList(buyCompleteRange);
            pointLock.lock();
            try {
                buyCompleteRange.clear();
                PriceLine currentPriceLine = getCurrentPriceLine(gridOrder.getFilledPrice());
                init(currentPriceLine);
            } finally {
                pointLock.unlock();
            }

            // 以前委托撤单
            while(!beforeCopy.isEmpty()){
                GridOrderDO gridOrderDO = beforeCopy.removeFirst();
                realCancel(gridOrderDO);
            }
            return;
        }

        // buy-first add
       openBuy(getPriceLine(gridOrder));
        // buy-last del
        realCancel(buyCompleteRange.removeLast());
    }

    /** 利润结算 */
    private void checkout(GridOrderDO sell){



        BigDecimal sellAmt = sell.getFilledNumber().multiply(sell.getFilledPrice());
        int parSize = 1;
        BigDecimal buyAmt;
        boolean firstLoss = First_Loss.equals(sell.getType());

        if(sell.isMerge()){

            List<Long> ids = Stream.of(sell.getMergeIds().split(",")).map(Long::valueOf).collect(Collectors.toList());
            List<GridOrderDO> buyMerge = orderService.batchBuyByIds(ids);

            buyAmt = buyMerge.stream().map(GridOrderDO::entrustAmt).reduce(BigDecimal.ZERO, BigDecimal::add);
            parSize = ids.size();

        }else {

            GridOrderDO buy = orderService.get(sell.getPairId());
            buyAmt = buy.filledAmt();
        }

        BigDecimal pairProfit =  sellAmt.subtract(buyAmt);

        synchronized (configStatus){
            if(firstLoss){
                configStatus.setLossProfit(configStatus.getLossProfit().add(pairProfit));
            }else{
            	configStatus.setPairSize(configStatus.getPairSize() + parSize);
            	configStatus.setPairProfit(configStatus.getPairProfit().add(pairProfit));
            	configStatus.setLossProfit(configStatus.getLossProfit().add(pairProfit));
            }

            saveConfigStatus();
        }
    }

    private void saveConfigStatus(){
        synchronized (configStatus) {

            GridConfigDO configDO = new GridConfigDO();
            configDO.setId(configId);
            configDO.setStatusConfig(JSONUtils.beanToJson(configStatus));
            configService.update(configDO);
        }
    }
    
    private void clearConfigStatus() {
    	configStatus.setLossProfit(BigDecimal.ZERO);
    	configStatus.setPairProfit(BigDecimal.ZERO);
    	configStatus.setPairSize(0);
    	configStatus.setTotalProfit(BigDecimal.ZERO);
    	configStatus.setConfigInfo(new ConfigInfo());
        synchronized (configStatus) {

            GridConfigDO configDO = new GridConfigDO();
            configDO.setId(configId);
            configDO.setStatusConfig(JSONUtils.beanToJson(configStatus));
            configService.update(configDO);
        }
        
    }

    /**
     * 挂单维护
     */
    private void rangeMaintain(GridOrderDO gridOrder){

        BigDecimal entrustPrice = gridOrder.getEntrustPrice();

        if(!buyFails.isEmpty()){

            List<PriceLine> buyLine = buyCompleteRange.stream().map(this::getPriceLine).collect(Collectors.toList());
            buyLine.addAll(buyPrepareRange.values().stream().map(this::getPriceLine).collect(Collectors.toList()));
            buyLine.sort(Comparator.comparing(PriceLine::getIndex).reversed());

            buyFails.removeIf(self->buyLine.stream().anyMatch(buy->buy.index == getPriceLine(self).index));

            List<Long> ids = Lists.newArrayList();
            // 当前价格 100块   可以挂单90块买进
            buyFails.stream()
                    .filter(self -> self.getEntrustPrice().compareTo(entrustPrice) < 0)
                    .map(self->{
                        ids.add(self.getId());
                        return getPriceLine(self);
                    })
                    .forEach(this::openBuy);

            buyFails.removeIf(self->ids.contains(self.getId()));
        }

        if(!sellFails.isEmpty()){

            // 当前价格 100块   可以挂单110块
            List<Long> ids = Lists.newArrayList();
            // 没有卖单
            sellFails.stream()
                    .filter(self->self.getEntrustPrice().compareTo(entrustPrice)  > 0)
                    .forEach(self->{
                        ids.add(self.getId());
                        openSell(self);
                    });
            sellFails.removeIf(self->ids.contains(self.getId()));

            sellFails.stream()
                    .filter(self->self.getEntrustPrice().compareTo(entrustPrice)  <= 0)
                    .forEach(self->{
                        ids.add(self.getId());
                        PriceLine priceLine = getPriceLine(gridOrder);
                        self.setEntrustPrice(priceLine.buyPrice);
                        openSell(self);
                    });
            sellFails.removeIf(self->ids.contains(self.getId()));
        }



    }

    /**
     * 撤单逻辑
     */
    private void strategyLogic(){
        // 0-直接撤单，1-不撤单
        boolean noCancel = Constant.YES.equals(configDO.getCancelType());
        if(noCancel) {

            firstLoss();
            sellRangeCheck();
        }else{
            cancelMerge();
        }

        log.info("sell.size:{} pre:{}  buy.size:{} pre:{} ", sellCompleteRange.size(), sellPrepareRange.size(), buyCompleteRange.size(), buyPrepareRange.size());
    }

    /**
     * 撤单合并
     */
    private void cancelMerge(){

        if(sellCompleteRange.isEmpty()) {
        	return;
        }
        
        GridOrderDO sellLast = sellCompleteRange.getLast();
        if(sellLast.isMerge()){
            return;
        }
        
        // 判断是否要合并
        {
            long size = sellCompleteRange.stream().filter(self->!self.isMerge()).count();
            log.info("非合并卖单 size:{} 区间数：{}",size, configDO.getRangeNum());
            if(size <= configDO.getRangeNum()){
                return;
            }
        }

        PriceLine priceLine = getPriceLine(sellLast);
        PriceLine preLine = lines.get(priceLine.index + 1);

        log.info("触发cancelMerge sellLast:{} range:{} preLine.range:{}", sellLast.getId(), priceLine.range, preLine.range);

        LinkedList<GridOrderDO> preRange = Lists.newLinkedList();

        log.info("卖单全部撤销");
        while(sellCompleteRange.size() > 1){

            GridOrderDO gridOrderDO = sellCompleteRange.removeFirst();
            preRange.addLast(gridOrderDO);
            realCancel(gridOrderDO);
        }

        log.info("sellRange.size:{} preRange.size:{}", sellCompleteRange.size(), preRange.size());
        
        final List<Long> cancelIds = preRange.stream().map(GridOrderDO::getId).collect(Collectors.toList());
       
        GridOrderDO alreadyMerge = null; // 已经合并
        if(preRange.getFirst().isMerge()){
        	alreadyMerge = preRange.removeFirst();
        	log.info("已经发生过alreadyMerge id:{} price:{} num:{}", alreadyMerge.getId(),alreadyMerge.getEntrustPrice(),alreadyMerge.getEntrustNumber());
        }
        
        String lossIds = preRange.stream().map(self->self.getId().toString()).collect(Collectors.joining(","));
        BigDecimal totalAmt = preRange.stream().map(self -> self.getEntrustPrice().multiply(self.getEntrustNumber())).reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal totalNum = preRange.stream().map(GridOrderDO::getEntrustNumber).reduce(BigDecimal.ZERO, BigDecimal::add);
        
        log.info("本次区间合并 totalAmt：{} totalNum：{} lossIds：{}", totalAmt, totalNum, lossIds);

        if(alreadyMerge != null){
        	totalAmt = totalAmt.add(alreadyMerge.getEntrustNumber().multiply(alreadyMerge.getEntrustPrice()));
        	totalNum = totalNum.add(alreadyMerge.getEntrustNumber());
        	lossIds = alreadyMerge.getMergeIds() + "," + lossIds;
        }
        
        BigDecimal totalAvg = totalAmt.divide(totalNum, symbolAccuracy.priceAccuracy(), RoundingMode.HALF_UP);
        String clientId = Constant.getClientOrderId();
        
        GridOrderDO merged = new GridOrderDO();
        merged.setConfigId(configId);
        merged.setCode(configDO.getCode());
        merged.setSymbol(symbol);
        merged.setTrendType(SIDE.SELL.toString());
        merged.setClientId(clientId);
        merged.setEntrustPrice(totalAvg);
        merged.setEntrustNumber(totalNum);
        merged.setEntrustTime(LocalDateTime.now());
        merged.setStatus(Constant.Order_Local);
        merged.setMergeIds(lossIds);
        orderService.save(merged);
        
        log.info("merged clientId:{} entrustPrice:{} entrustNum:{} lossIds:{}", clientId, totalAvg,totalNum,lossIds);

        String order  = IdUtil.nanoId();
        log.info("task-addFirst openOrder:{}",order);
        
        final BigDecimal totalNumCopy = totalNum;
        
        task.addFirst(()->{
        	
        	GridOrderDao gridOrderDao = orderService.getGridOrderDao();
        	for(;;) {
        		
        		List<GridOrderDO> selectBatchIds = gridOrderDao.selectBatchIds(cancelIds);
        		if(selectBatchIds.stream().allMatch(self->Constant.Order_Cancel.equals(self.getStatus()))) {
        			break;
        		}
        		try {
					TimeUnit.MILLISECONDS.sleep(30);
				} catch (InterruptedException e) {
				}
        	}
        	
        	log.info("task-openOrder:{}",order);
        	openOrder(SIDE.SELL, totalAvg, totalNumCopy, clientId);
        });
        
        LockSupport.unpark(master);
    }

    /**
     * 首单止损  亏 X 盈利 x*N
     */
    private void firstLoss(){

    	if(buyCompleteRange.isEmpty() || sellCompleteRange.isEmpty()) {
    		return;
    	}
        GridOrderDO first = buyCompleteRange.getFirst();
        PriceLine priceLine = getPriceLine(first);

        GridOrderDO sellFirst = sellCompleteRange.getFirst();
        if(First_Loss.equals(sellFirst.getType())){
            return;
        }
        BigDecimal sellAmt = sellFirst.entrustAmt();

        // 跌幅
        BigDecimal fall = sellFirst.fall(priceLine.sellPrice);
        BigDecimal fallSell = sellAmt.multiply(fall);
        // 可以补偿金额
        BigDecimal compensateAmt = configStatus.getLossProfit().multiply(otherConfig.getCompensate());

        
        ConfigInfo configInfo = configStatus.getConfigInfo();
        configInfo.setFirstAmt(fallSell);
        configInfo.setFirstFall(fall);
        configInfo.setCompensateAmt(compensateAmt);
        
        boolean b = fall.compareTo(otherConfig.getHeadOrderFall()) >= 0;
        boolean c = compensateAmt.compareTo(fallSell) >= 0;
        log.info("首单止损 跌幅:{} 亏损:{} 可补:{} set.fall:{} set.comp:{}\r\nb:{} c:{}",fall,fallSell,
                compensateAmt,otherConfig.getHeadOrderFall(),otherConfig.getCompensate(),b,c);
        if (b && c) {

            sellFirst.setType(First_Loss);
            realCancel(sellFirst);

            task.addFirst(()->{

                GridOrderDO update = new GridOrderDO();
                update.setType(First_Loss);
                update.setId(sellFirst.getId());
                orderService.update(update);

                int i = 0;
                for(;;){
                    GridOrderDO gridOrderDO = orderService.get(sellFirst.getId());
                    if(i > 10 || Constant.Order_Cancel.equals(gridOrderDO.getStatus())){
                        break;
                    }
                    i++;
                    try {
                        TimeUnit.MILLISECONDS.sleep(100);
                    } catch (InterruptedException ignored) {
                    }
                }
                // 首单 市价平仓
                openOrderMaker(sellFirst.getEntrustNumber(),sellFirst.getClientId());
            });
            LockSupport.unpark(master);
        }

    }

    private void sellRangeCheck() {

        if(!Constant.YES.equals(configDO.getCancelType())) {
            return;
        }

        GridOrderDao gridOrderDao = orderService.getGridOrderDao();

        int half = Sell_Size / 2;
        int sellRangeSize = sellCompleteRange.size();
        if(sellRangeSize > Sell_Size) {

            GridOrderDO remove = sellCompleteRange.remove(half);
            realCancel(remove);
            GridOrderDO update = new GridOrderDO();
            update.setId(remove.getId());
            update.setSellLoad(Constant.Order_Load);
            orderService.update(update);
            log.info("sellRangeCheck sellRangeSize:{} remove.id:{}",sellRangeSize,remove.getId());
            return;
        }


        if(sellRangeSize < Sell_Size ) {


            long count = gridOrderDao.selectCount(Wrappers.lambdaQuery(GridOrderDO.class)
                    .eq(GridOrderDO::getConfigId, configId)
                    .eq(GridOrderDO::getSellLoad, Constant.Order_Load));

            if(count <= 0) {
                return;
            }

            List<GridOrderDO> selectList = gridOrderDao.selectList(Wrappers.lambdaQuery(GridOrderDO.class)
                    .eq(GridOrderDO::getConfigId, configId)
                    .eq(GridOrderDO::getSellLoad, Constant.Order_Load)
                    .orderByDesc(GridOrderDO::getEntrustPrice));


            List<PriceLine> sort = sellCompleteRange.stream().map(this::getPriceLineSub).collect(Collectors.toList());

            int index = sort.get(0).index;
            boolean isHead = false;
            for(int i=1; i < half; i++) {

                PriceLine priceLine = sort.get(i);
                if(priceLine.index - index != 1 ) {
                    isHead = true;
                    break;
                }
                index = priceLine.index;
            }

            int head = isHead ? 0: selectList.size() - 1;
            GridOrderDO gridOrderDO = selectList.get(head);
            sellCompleteRange.add(isHead ? half - 1 : half, gridOrderDO);
            openOrder(SIDE.valueOf(gridOrderDO.getTrendType()), gridOrderDO.getEntrustPrice(), gridOrderDO.getEntrustNumber(), gridOrderDO.getClientId());

            GridOrderDO update = new GridOrderDO();
            update.setId(gridOrderDO.getId());
            update.setSellLoad(Constant.Blank);
            orderService.update(update);

            log.info("sellRangeCheck sellRangeSize:{} add.id:{}  isHead:{}",sellRangeSize,gridOrderDO.getId(),isHead);
        }

    }


    /**
     * 买单生成
     * @param priceLine 网格线
     * @return 买单
     */
    private void openBuy(PriceLine priceLine){


        int range = priceLine.range;

        if(range < minRange){
            range = minRange;
        }
        if(range > maxRange){
            range = maxRange;
        }

        BigDecimal buyPrice = priceLine.buyPrice;
        BigDecimal singleAmt = configDO.getSingleAmt();
        RangeProDO rangeProDO = rangeProMap.get(range);
        BigDecimal totalAmt = singleAmt.multiply(rangeProDO.getProValue());


        BigDecimal qtyTick = symbolAccuracy.qtyTick;
        BigDecimal qyt = qtyTick;

        for(;;){

            if(qyt.multiply(buyPrice).compareTo(totalAmt) >= 0){
                break;
            }
            qyt = qyt.add(qtyTick);
        }

        log.info("openBuy 单次金额:{} 区间:{} 倍投:{} 倍投-Amt:{} qty:{} buyPrice:{}", singleAmt, rangeProDO.getRangeIndex(),rangeProDO.getProValue(),totalAmt,qyt,buyPrice);

        priceLine.qty = qyt;
        GridOrderDO gridOrderDO = realOpen(priceLine, SIDE.BUY);
        buyPrepareRange.put(gridOrderDO.getClientId(),gridOrderDO);
        // return realOpen.apply(priceLine,SIDE.BUY);
    }

    /**
     * 卖单生成
     * @param gridOrder 成交的买单
     * @return 卖单
     */
    private void openSell(GridOrderDO gridOrder){

        PriceLine priceLine = getPriceLine(gridOrder);
        priceLine.orderId = gridOrder.getId();
        priceLine.qty = gridOrder.getFilledNumber();

        GridOrderDO gridOrderDO = realOpen(priceLine, SIDE.SELL);
        sellPrepareRange.put(gridOrderDO.getClientId(),gridOrderDO);
    }

    public PriceLine getPriceLine(GridOrderDO gridOrder){

        PriceLine priceLineSub = getPriceLineSub(gridOrder);
        if(priceLineSub == null){
            log.error("getPriceLine - 无法根据order获取PriceLine id:{}", gridOrder.getId());
            return getCurrentPriceLine(gridOrder.getEntrustPrice());
        }
        return priceLineSub;
    }


    public PriceLine getPriceLineSub(GridOrderDO gridOrder){

        BigDecimal key = gridOrder.getEntrustPrice().setScale(symbolAccuracy.priceAccuracy(), RoundingMode.HALF_UP);

        if(Constant.BUY.equals(gridOrder.getTrendType())){
            return  buyLines.get(key);
        }
        return  sellLines.get(key);
    }

    private PriceLine getCurrentPriceLine(BigDecimal price){

    	
    	PriceLine current = null;
    	int size = lines.size();
    	try {
			
    		
    		for(int i = 0; i < size; i++){
    			
    			PriceLine priceLine = lines.get(i);
    			
    			if(price.compareTo(priceLine.buyPrice) >= 0 && price.compareTo(priceLine.sellPrice) < 0){
    				current = priceLine;
    			}
    		}
    		return current;
		} finally {
			log.info("getCurrentPriceLine param price:{} size:{} current:{}",price,size, current == null ? null : current.buyPrice);
		}
    }

    private SymbolAccuracy getSymbolAccuracyInfo(String symbol) {

        Market market = Constant.spotClient.createMarket();

        Map<String, Object> parameters = Maps.newHashMap();
        parameters.put("symbol",symbol);
        String exchangeInfo = market.exchangeInfo(parameters);
        JSONObject jsonObject = new JSONObject(exchangeInfo);
        JSONArray symbols = jsonObject.getJSONArray("symbols");
        if(symbols.length() != 1){
            throw  new RuntimeException("exchangeInfo-symbol:"+symbol + " 没找到");
        }

        JSONArray filters = symbols.getJSONObject(0).getJSONArray("filters");

        Optional<JSONObject> priceFilter = StreamSupport.stream(filters.spliterator(), false)
                .map(self -> (JSONObject) self)
                .filter(self -> "PRICE_FILTER".equals(self.getString("filterType")))
                .findFirst();

        Optional<JSONObject> lotSize = StreamSupport.stream(filters.spliterator(), false)
                .map(self -> (JSONObject) self)
                .filter(self -> "LOT_SIZE".equals(self.getString("filterType")))
                .findFirst();

        JSONObject PRICE_FILTER = priceFilter.orElseThrow(() -> new RuntimeException("symbol - PRICE_FILTER 找不到" + symbol));
        JSONObject LOT_SIZE = lotSize.orElseThrow(() -> new RuntimeException("symbol - LOT_SIZE 找不到" + symbol));
//
        BigDecimal priceTick = PRICE_FILTER.getBigDecimal("tickSize").stripTrailingZeros();

        BigDecimal qtyTick = LOT_SIZE.getBigDecimal("stepSize").stripTrailingZeros();

        return new SymbolAccuracy(priceTick,qtyTick);
    }


    private List<PriceLine> generateLine(){

        // true  均利  按最低利润率获取买入卖出线
        // false 均价  按价格间距获取买入卖出线
        boolean gridType = Constant.YES.equals( configDO.getGridType());

        BigDecimal gridValue = configDO.getGridValue();
        BigDecimal minPrice = configDO.getMinPrice();
        BigDecimal maxPrice = configDO.getMaxPrice();

        List<PriceLine> lineList = Lists.newArrayList();
        int index = 0;

        BigDecimal priceTick = symbolAccuracy.priceTick;

        BigDecimal buyPrice = symbolAccuracy.priceTick;
        BigDecimal sellPrice = symbolAccuracy.priceTick;

        for (;;){

            if(buyPrice.compareTo(maxPrice) > 0){
                break;
            }

            if(gridType){

                while (sellPrice.subtract(buyPrice).divide(buyPrice, 8, RoundingMode.HALF_UP).compareTo(gridValue) < 0) {
                    sellPrice = sellPrice.add(priceTick);
                }
            }else{
                sellPrice = sellPrice.add(gridValue);
            }

            if(buyPrice.compareTo(minPrice) >= 0){

                PriceLine priceLine = new PriceLine(index, buyPrice, sellPrice);
                lineList.add(priceLine);
                buyLines.put(priceLine.buyPrice,priceLine);
                sellLines.put(priceLine.sellPrice,priceLine);
                index++;
            }
            buyPrice = sellPrice;
        }
        log.info("generateLine - lineList:{}",lineList.size());
        return lineList;
    }



    public GridOrderDO realOpen(PriceLine priceLine,SIDE side){

        boolean isBuy = SIDE.BUY == side;
        String clientOrderId = Constant.getClientOrderId();
        BigDecimal price = isBuy ? priceLine.buyPrice : priceLine.sellPrice;

        GridOrderDO gridOrder = new GridOrderDO();
        gridOrder.setConfigId(configId);
        gridOrder.setCode(configDO.getCode());
        gridOrder.setSymbol(symbol);
        gridOrder.setTrendType(side.toString());
        gridOrder.setClientId(clientOrderId);
        gridOrder.setEntrustPrice(price);
        gridOrder.setEntrustNumber(priceLine.qty);
        gridOrder.setEntrustTime(LocalDateTime.now());
        gridOrder.setStatus(Constant.Order_Local);
        if(!isBuy){
            gridOrder.setPairId(priceLine.orderId);
        }
        orderService.save(gridOrder);

        log.info("realOpen index:{} range:{} side:{} price:{} clientId:{}\r\n{}", priceLine.index,priceLine.range,side,price,clientOrderId,JSONUtils.beanToJson(gridOrder));

        openOrder(side,price,priceLine.qty,clientOrderId);
        return gridOrder;
    }

    public void realCancel(GridOrderDO gridOrder){

        PriceLine priceLine = getPriceLine(gridOrder);

        log.info("realCancel index:{} range:{} side:{} price:{} clientId:{}\r\n{}", priceLine.index,priceLine.range,gridOrder.getTrendType(),gridOrder.getEntrustPrice(),gridOrder.getClientId(),JSONUtils.beanToJson(gridOrder));

        cancelOrder(gridOrder.getClientId());

    }


    /// SPOT - WebSocketAPI

    private final Map<String, String> requestIdClientId = Maps.newConcurrentMap();
    private final Map<String, Consumer<com.alibaba.fastjson2.JSONObject>> callbackMethod = Maps.newConcurrentMap();

    private String getRequestId(Consumer<com.alibaba.fastjson2.JSONObject> callback,String clientId){

        while (true){
            String simpleUUID = IdUtil.fastSimpleUUID();

            if( !callbackMethod.containsKey(simpleUUID)){
                callbackMethod.put(simpleUUID, callback);
                requestIdClientId.put(simpleUUID, clientId);
                return simpleUUID;
            }

        }
    }

    /**
     * 下单
     * @param side 方向
     * @param price 价格
     * @param quantity 数量
     * @param clientId clientId
     */
    private void openOrder(SIDE side, BigDecimal price,BigDecimal quantity,String clientId){

        String symbol = this.symbol;
        String sideStr = side.toString();
        String type = SpotGridManager.ENV ? "LIMIT_MAKER" : "LIMIT";

        JSONObject parameters = new JSONObject();
        parameters.put("price",price.stripTrailingZeros().toPlainString());
        parameters.put("quantity",quantity.stripTrailingZeros().toPlainString());
        parameters.put("newClientOrderId",clientId);
        if(SpotGridManager.ENV == false) {
            parameters.put("timeInForce", "GTC");
        }
        String requestId = getRequestId(this::onOpenOrder,clientId);
        parameters.put("requestId", requestId);

        trade.newOrder(symbol,sideStr,type,parameters);

        log.info("openOrder requestId:{} parameters:{}",requestId,parameters);
    }

    /**
     * 市价下单
     * @param quantity 数量
     * @param clientId clientId
     */
    private void openOrderMaker(BigDecimal quantity,String clientId){


        String symbol = this.symbol;
        String type = "MARKET";

        JSONObject parameters = new JSONObject();
        parameters.put("quantity",quantity.stripTrailingZeros().toPlainString());
        parameters.put("newClientOrderId",clientId);
        String requestId = getRequestId(this::onOpenOrder,clientId);
        parameters.put("requestId", requestId);

        trade.newOrder(symbol,"SELL",type,parameters);
        log.info("openOrderMaker requestId:{} parameters:{}",requestId,parameters);
    }

    private void onOpenOrder(com.alibaba.fastjson2.JSONObject data){
        Constant.setMDC(mdc);

        com.alibaba.fastjson2.JSONObject result = data.getJSONObject("result");
        String clientOrderId = result.getString("clientOrderId");

        GridOrderDO gridOrder = orderService.getByClientId(clientOrderId);
        if (gridOrder == null) {
            return;
        }

        orderNew(gridOrder.getId(),result.getString("orderId"),clientOrderId);

        boolean isBuy = Constant.BUY.equals(gridOrder.getTrendType()) ;
        Map<String,GridOrderDO> prepareRange = isBuy ? buyPrepareRange : sellPrepareRange;
        LinkedList<GridOrderDO> completeRange = isBuy ? buyCompleteRange : sellCompleteRange;
        GridOrderDO remove = prepareRange.get(clientOrderId);
        if(remove != null){

            log.info("prepareRange-clientId:{}",clientOrderId);
            completeRange.add(remove);
            // 从大到小 排序
            completeRange.sort(Comparator.comparing(GridOrderDO::getEntrustPrice).reversed());
            prepareRange.remove(clientOrderId);
        }

        Runnable success = orderSuccess.remove(clientOrderId);
        if(success != null ){
            log.info("orderSuccess-clientId:{}",clientOrderId);
            success.run();
        }

    }


    private void cancelOrder(String clientId){

        String symbol = this.symbol;
        JSONObject parameters = new JSONObject();
        parameters.put("origClientOrderId",clientId);
        String requestId = getRequestId(this::onCancelOrder,clientId);
		parameters.put("requestId", requestId);
        trade.cancelOrder(symbol,parameters );
        log.info("cancelOrder requestId:{} parameters:{}",requestId,parameters);
    }

    private void onCancelOrder(com.alibaba.fastjson2.JSONObject data){
        Constant.setMDC(mdc);

        com.alibaba.fastjson2.JSONObject result = data.getJSONObject("result");
        String clientOrderId = result.getString("origClientOrderId");
        GridOrderDO gridOrder = orderService.getByClientId(clientOrderId);

        String status = result.getString("status");
        if(Constant.Order_Cancel.equals(status)){
            orderCancel(gridOrder.getId(),clientOrderId);
            return;
        }
        log.error("onCancelOrder 撤单失败 clientOrderId：{} data:{}",clientOrderId,data);
    }

    private void orderNew(Long id,String orderId,String clientOrderId){

        GridOrderDO update = new GridOrderDO();
        update.setId(id);
        update.setOrderId(orderId);
        update.setStatus(Constant.Order_NEW);
        log.info("orderNew clientId:{} id:{} orderId:{}",clientOrderId,id,orderId);
        orderService.update(update);
    }

    private void orderCancel(Long id,String clientOrderId){

        GridOrderDO update = new GridOrderDO();
        update.setId(id);
        update.setStatus(Constant.Order_Cancel);
        update.setFilledTime(LocalDateTime.now());
        log.info("orderCancel clientId:{} id:{}",clientOrderId,id);
        orderService.update(update);
    }

    private void orderFilled(Long id,String clientOrderId,BigDecimal filledNumber,BigDecimal filledPrice){

        GridOrderDO update = new GridOrderDO();
        update.setId(id);
        update.setStatus(Constant.Order_Filled);
        update.setFilledNumber(filledNumber);
        update.setFilledPrice(filledPrice);
        update.setFilledTime(LocalDateTime.now());
        log.info("orderFilled clientId:{} id:{} filledNumber:{} filledPrice:{}",clientOrderId,id,filledNumber,filledPrice);
        orderService.update(update);

        orderFilled(orderService.get(id));
    }

    public void userDataNew(ApiTrackDO apiTrackDO, GridOrderDO byClientId){
        Constant.setMDC(mdc);
        log.info("userDataNew id:{} side:{} clientId:{}\r\napiTrackDO:{}",byClientId.getId(),byClientId.getTrendType(),byClientId.getClientId(),JSONUtils.beanToJson(apiTrackDO));
        orderNew(byClientId.getId(),apiTrackDO.getOrderId().toString(), byClientId.getClientId());
    }

    public void userDataCancel(ApiTrackDO apiTrackDO, GridOrderDO byClientId){
        Constant.setMDC(mdc);
        log.info("userDataCancel id:{} side:{} clientId:{}\r\napiTrackDO:{}",byClientId.getId(),byClientId.getTrendType(),byClientId.getClientId(),JSONUtils.beanToJson(apiTrackDO));
        orderCancel(byClientId.getId(),byClientId.getClientId());
    }

    public void userDataFilled(ApiTrackDO apiTrackDO, GridOrderDO byClientId){
        Constant.setMDC(mdc);
        log.info("userDataFilled id:{} side:{} clientId:{}\r\napiTrackDO:{}",byClientId.getId(),byClientId.getTrendType(),byClientId.getClientId(),JSONUtils.beanToJson(apiTrackDO));

        if(Constant.Order_Local.equals(byClientId.getStatus())){
            log.info("userDataFilled-Order_Local:{}",byClientId.getClientId());
            orderSuccess.put(byClientId.getClientId(),()->orderFilled(byClientId.getId(),byClientId.getClientId(),apiTrackDO.getAccumulatedQuantity(),apiTrackDO.realAvgPrice()));
        }
        orderFilled(byClientId.getId(),byClientId.getClientId(),apiTrackDO.getAccumulatedQuantity(),apiTrackDO.realAvgPrice());
    }

    /**
     * 订单已成交 还未下单成功
     */
    private final Map<String,Runnable> orderSuccess = Maps.newHashMap();


    private void connect(){
        webSocketInfo.connectTime = LocalDateTime.now();
        webSocketInfo.openFlag = false;
        webSocketInfo.closeFlag = false;
        webSocketInfo.timeoutFlag = false;
        webSocketInfo.reconnectSize++;

        apiClient.connect(this::onOpen,this::onMessage,this::onClosing,this::onClosed,this::onFailure);
        trade = apiClient.trade();

        log.info("connect-{}", JSONUtils.beanToJson(webSocketInfo));
    }


    private boolean webSocketStatus(){

        // 连接关闭
        if(webSocketInfo.openFlag && webSocketInfo.closeFlag){
            log.info("webSocket-status 重新连接：{}", JSONUtils.beanToJson(webSocketInfo));
            connect();
            return false;
        }

        // 连接超时
        if(!webSocketInfo.openFlag && !webSocketInfo.timeoutFlag && LocalDateTime.now().isAfter(webSocketInfo.connectTime.plus(webSocketInfo.waitConnectTime))){
            apiClient.close();
            webSocketInfo.timeoutFlag = true;
            log.info("webSocket-status 连接超时：{}", JSONUtils.beanToJson(webSocketInfo));
            return  false;
        }

        // 重新连接
        if(webSocketInfo.timeoutFlag && webSocketInfo.reconnectSize <= 10){
            connect();
            log.info("webSocket-status 连接超时-重新连接：{}", JSONUtils.beanToJson(webSocketInfo));
            return false;
        }

        if(webSocketInfo.openFlag && !webSocketInfo.closeFlag && !webSocketInfo.timeoutFlag){
            return true;
        }

        return false;


    }

    private void onOpen(Response response){

        Constant.setMDC(mdc);

        webSocketInfo.openFlag = true;
        webSocketInfo.reconnectSize = 0;
        log.info("open-{}",JSONUtils.beanToJson(webSocketInfo));

        if(!buyCompleteRange.isEmpty() || !sellCompleteRange.isEmpty() || !buyPrepareRange.isEmpty()){
            return;
        }

        boolean load = load();
        if(!load){
            init();
        }
    }

    private void onMessage(String data){

        executorService.execute(()->onMessageRel(data));

    }

    private void onMessageRel(String data){

        Constant.setMDC(mdc);

        com.alibaba.fastjson2.JSONObject jsonObject = JSON.parseObject(data);
        String id = jsonObject.getString("id");
        Consumer<com.alibaba.fastjson2.JSONObject> jsonObjectConsumer = callbackMethod.remove(id);
        String clientId = requestIdClientId.remove(id);
        int status = jsonObject.getIntValue("status");
        if(status != 200){


/*            // 重试
            if(status == 1000 || status == 10001){

            }
            //请求过多
            if(status == 1003){

            }
            //服务器正忙，请稍候再试。
            if(status == 1004){

            }*/
            if(status == 400) {
            	
            	com.alibaba.fastjson2.JSONObject jsonObject2 = jsonObject.getJSONObject("error");
            	int code = jsonObject2.getIntValue("code");
            	// 委托挂单 时机错过
            	if(code == -2010 && clientId != null) {
            		
            		GridOrderDO byClientId = orderService.getByClientId(clientId);
            		if(byClientId != null) {
            			
            			orderCancel(byClientId.getId(), clientId);
            			if(Constant.BUY.equals(byClientId.getTrendType())) {

                            buyPrepareRange.remove(clientId);
                            buyFails.add(byClientId);
            			}else {

                            sellPrepareRange.remove(clientId);
                            sellFails.add(byClientId);
            			}
            			
            			log.info("委托挂单 时机错过 clientId:{}",clientId);
            			return;
            		}
            	}
            }
            log.error("onMessage-{}",data);
            return;
        }

        try {
            if (jsonObjectConsumer != null){
            	log.info("callback-requestId:{}",id);
                jsonObjectConsumer.accept(jsonObject);
            }
        } catch (Exception e) {
            log.error("callbackMethod-{}\r\njsonObject:{}",id,jsonObject,e);
        }

    }

    private void onClosing(int code, String reason){

    }
    private void onClosed(int code, String reason){
        Constant.setMDC(mdc);

        webSocketInfo.closeFlag = true;
        log.info("close-{}", JSONUtils.beanToJson(webSocketInfo));
        LockSupport.unpark(master);
    }
    private void onFailure(Throwable t, Response response){
        Constant.setMDC(mdc);

        webSocketInfo.failureSize++;
        log.error("onFailure",t);
    }
    /// SPOT - WebSocketAPI


    @Getter
    @Setter
    static class WebSocketInfo {

        final Duration waitConnectTime = Duration.ofSeconds(3) ;

        LocalDateTime connectTime;

        int reconnectSize;

        int failureSize;

        boolean timeoutFlag;

        boolean openFlag;

        boolean closeFlag;
    }

    static class SymbolAccuracy{

        public SymbolAccuracy(BigDecimal priceTick, BigDecimal qtyTick) {

            this.priceTick = priceTick;
            this.qtyTick = qtyTick;
        }

        /**步进价格*/
        private final BigDecimal priceTick;


        public int priceAccuracy(){
            return priceTick.scale();
        }

        /**步进数量*/
        private final BigDecimal qtyTick;

        public int qtyAccuracy(){
            return qtyTick.scale();
        }

        /** 最低订单金额 */
        private BigDecimal minNotional;

        /** 最高订单金额 */
        private BigDecimal maxNotional;
    }

    public static class PriceLine{

        @Getter
        final int index;

        int range;

        final BigDecimal buyPrice;

        BigDecimal qty;

        Long orderId;

        final BigDecimal sellPrice;



        public PriceLine(int index, BigDecimal buyPrice, BigDecimal sellPrice) {
            this.index = index;
            this.buyPrice = buyPrice;
            this.sellPrice = sellPrice;
        }

    }
}

