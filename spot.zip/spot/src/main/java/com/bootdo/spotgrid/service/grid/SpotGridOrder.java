package com.bootdo.spotgrid.service.grid;


import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.RandomUtil;
import com.alibaba.fastjson2.JSON;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.binance.connector.client.WebSocketApiClient;
import com.binance.connector.client.impl.WebSocketApiClientImpl;
import com.binance.connector.client.impl.spot.Market;
import com.binance.connector.client.impl.websocketapi.WebSocketApiTrade;
import com.binance.connector.client.utils.signaturegenerator.HmacSignatureGenerator;
import com.bootdo.common.utils.JSONUtils;
import com.bootdo.common.utils.StringUtils;
import com.bootdo.spotgrid.common.Constant;
import com.bootdo.spotgrid.common.websocket.dto.BookTicker;
import com.bootdo.spotgrid.dao.AccountDao;
import com.bootdo.spotgrid.dao.GridRangeDao;
import com.bootdo.spotgrid.domain.*;
import com.bootdo.spotgrid.service.ApiTrackService;
import com.bootdo.spotgrid.service.GridConfigService;
import com.bootdo.spotgrid.service.GridOrderService;
import com.bootdo.spotgrid.vo.ConfigInfo;
import com.bootdo.spotgrid.vo.ConfigStatus;
import com.bootdo.spotgrid.vo.OtherConfig;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Queues;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.LockSupport;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@Slf4j
public class SpotGridOrder extends Thread{

    final Long configId;

    @Getter
    final String symbol;

    final GridConfigDO configDO;

    final WebSocketInfo webSocketInfo = new WebSocketInfo();

    final WebSocketApiClient apiClient;

    WebSocketApiTrade trade;

    final Thread master = this;

    final ApiTrackService apiTrackService;

    final GridOrderService orderService;

    final GridConfigService configService;

    @Getter
    final String mdc;

    /// 网格订单
    private final SymbolAccuracy symbolAccuracy;

    private final OtherConfig otherConfig;

    @Getter
    private final ConfigStatus configStatus;

    /** 网格价格线 */
    private final List<PriceLine> lines;

    private final int lineSize;

    private final AtomicReference<BigDecimal> buyPriceRef = new AtomicReference<>(BigDecimal.ZERO);
    private final AtomicReference<BigDecimal> sellPriceRef = new AtomicReference<>(BigDecimal.ZERO);

    private final AtomicReference<PriceLine> headBuyRef = new AtomicReference<>(null);
    private final AtomicReference<PriceLine> headSellRef = new AtomicReference<>(null);
    private final AtomicReference<PriceLine> lastSellRef = new AtomicReference<>(null);

    /**卖单 委托数量 load*/
    private final AtomicInteger sellOrderSize = new AtomicInteger(0);
    /**卖单 搁置数量 load*/
    private final AtomicInteger shelveOrderSize = new AtomicInteger(0);
    /**起始价格*/
    private final AtomicReference<BigDecimal> startPriceRef = new AtomicReference<>(null);

    @Getter
    private List<PriceLine> buyPriceLine = null;
    @Getter
    private List<PriceLine> sellPriceLine = null;

    private final Map<BigDecimal, PriceLine> buyLines = Maps.newHashMap();
    private final Map<BigDecimal, PriceLine> sellLines = Maps.newHashMap();

    /** 卖单失败 */
    private final Queue<GridOrderDO> sellFails = Queues.newArrayBlockingQueue(100);

    /** 价格多挂一格单子 的 买单 */
    private final Queue<GridOrderDO>  upLineOrder = Queues.newArrayBlockingQueue(100);

    /** 卖单最大挂单数 */
    static final int Sell_Size = 30;
    private final Map<Integer, RangeProDO> rangeProMap;
    private final int minRange,maxRange;

    ///
    private final AtomicBoolean running = new AtomicBoolean(true);

    private final AtomicBoolean linkStatus = new AtomicBoolean(false);

    public boolean getRunning(){
        return running.get();
    }
    public void runningStop(){
        running.set(false);
    }

    public void cancelAllStop(){
        running.set(false);


        List<GridOrderDO> ordersByWait = orderService.getOrdersByWait(configDO);
        for (GridOrderDO gridOrderDO : ordersByWait) {
            cancelOrderReq(gridOrderDO.getClientId());
        }

        lines.forEach(self->{
            self.buyOrder = null;
        });

        clearConfigStatus();
    }



    public SpotGridOrder(Long configId, ExecutorService executorService, ApiTrackService apiTrackService, GridOrderService orderService, GridConfigService configService, GridRangeDao rangeDao, AccountDao accountDao) {
        this.configId = configId;
        this.configService = configService;
        this.configDO = configService.get(configId);
        this.otherConfig = configDO.selfOtherConfig();
        this.configStatus = configDO.selfStatusConfig();
        this.symbol = configDO.getBaseAsset() + configDO.getQuoteAsset();
        this.symbolAccuracy = getSymbolAccuracyInfo(symbol);
        this.orderService = orderService;
        this.apiTrackService = apiTrackService;
        this.lines = generateLine();
        this.lineSize = lines.size();
        this.rangeProMap = rangeDao.selectList(null).stream().collect(Collectors.toMap(RangeProDO::getRangeIndex, Function.identity()));
        this.minRange = rangeProMap.keySet().stream().min(Integer::compare).get();
        this.maxRange = rangeProMap.keySet().stream().max(Integer::compare).get();
        this.executorService = executorService;

        setName(configDO.getAccountName() + "-" + symbol);
        this.mdc = "order-grid-" + getName();

        if(StringUtils.isBlank(configDO.getCode())){
            String randomString = RandomUtil.randomString(6);
            configDO.setCode(randomString);

            GridConfigDO update = new GridConfigDO();
            update.setCode(randomString);
            update.setId(configId);
            configService.update(update);
        }

        AccountDO account = accountDao.selectOne(Wrappers.lambdaQuery(AccountDO.class).eq(AccountDO::getAccountName, configDO.getAccountName()));
        HmacSignatureGenerator signatureGenerator = new HmacSignatureGenerator(account.getAccountSecret());
        apiClient = new WebSocketApiClientImpl(account.getAccountKey(),signatureGenerator,SpotGridManager.URL_ORDER_WEBSOCKET);

    }

    /** 网格头尾单处理*/
    private final ExecutorService executorService;

    /**
     * 首单撤单 等待 市价卖出
     */
    private final LinkedBlockingDeque<Runnable> task = Queues.newLinkedBlockingDeque();


    @Override
    public void run() {

        Constant.setMDC(mdc + "-info");

        connect();
        LocalDateTime now = LocalDateTime.now();
        while(running.get()){

            try {
                if(!task.isEmpty()) {
                    while(!task.isEmpty()) {
                        task.pollLast().run();
                    }
                }

                LocalDateTime tmp = LocalDateTime.now();
                if(Duration.between(now, tmp).getSeconds() >= 5){
                    now = tmp;
                    webSocketStatus();
                    gridInStatus();
                    if(firstLoss()){
                        // 暂停1秒
                        LockSupport.parkNanos(master, 1000 * 1000L * 1000L);
                    }
                    sellRangeCheck();
                    upLineOrderHandle();
                }

            } catch (Exception e) {
                log.error("run-exit",e);
                runningStop();
                break;
            } finally {
                // 暂停5秒
                LockSupport.parkNanos(master,1000 * 1000L * 1000L * 3);
            }
        }
    }

    private void gridInStatus(){

        PriceLine priceLine = headBuyRef.get();
        String buy = "";
        if(priceLine != null){
            buy = priceLine.range + " " + priceLine.buyOrder.getEntrustNumber().stripTrailingZeros().toPlainString();
        }


        String sell = lastSellRef.get() == null ? "" : lastSellRef.get().sellPrice.stripTrailingZeros().toPlainString();
        String sellHead = headSellRef.get() == null ? "" : headSellRef.get().sellPrice.stripTrailingZeros().toPlainString();


        log.info("买入价:{} 买入头单:{}\r\n" +
                 "卖出价:{} 卖出尾单:{} 卖出头单：{} 卖单数：{} 卖单搁置数：{} websocketAPI:{}",buyPriceRef.get(), buy,sellPriceRef.get(),sell,sellHead,sellOrderSize.get(),shelveOrderSize.get(),linkStatus.get());
    }

    // 买单下单 维护
    public void bookTicker(BookTicker bookTicker){

        final BigDecimal sellPrice = bookTicker.getSellPrice();
        final BigDecimal buyPrice = bookTicker.getBuyPrice();

        if(sellPriceRef.get().compareTo(sellPrice) != 0){
            sellPriceRef.set(sellPrice);
        }

        if(buyPriceRef.get().compareTo(buyPrice) == 0){
            return;
        }
        buyPriceRef.set(buyPrice);

        if(!running.get() || !linkStatus.get()){
            return;
        }

        executorService.execute(()->{

            buyPlaceOrder(buyPrice);

            sellRangeLine();
        });

    }

    private void sellRangeLine(){
        PriceLine lastSell = lastSellRef.get();
        PriceLine headSell = headSellRef.get();
        if(lastSell == null || headSell == null){
            return;
        }

        sellPriceLine = lines.subList(lastSell.index,headSell.index);
    }

    private void buyPlaceOrder(final BigDecimal buyPrice){

        final PriceLine headBuy = headBuyRef.get();
        // 首次没有 委托单
        if(headBuy == null){
            PriceLine currentPriceLine = getCurrentPriceLine(buyPrice);
            openRange(currentPriceLine);
            return;
        }

        if(buyPrice.compareTo(headBuy.buyPrice) >= 0 && buyPrice.compareTo(headBuy.sellPrice) < 0){
            return;
        }

        // 价格上涨 first 设置
        if(buyPrice.compareTo(headBuy.sellPrice) > 0){
            for(int i = headBuy.index; i < lineSize; i++){
                PriceLine priceLine = lines.get(i);
                if(buyPrice.compareTo(priceLine.buyPrice) >= 0 && buyPrice.compareTo(priceLine.sellPrice) < 0){
                    openRange(priceLine);
                    return;
                }
            }
        }

        // 价格下跌 first 设置
        if(buyPrice.compareTo(headBuy.buyPrice) < 0){
            for(int i = headBuy.index; i >= 0 ; i--){
                PriceLine priceLine = lines.get(i);
                if(buyPrice.compareTo(priceLine.buyPrice) >= 0 && buyPrice.compareTo(priceLine.sellPrice) < 0){
                    openRange(priceLine);
                    return;
                }
            }
        }
    }

    private void openRange(PriceLine currentPriceLine){

        headBuyRef.set(currentPriceLine);

        int to = currentPriceLine.index;
        int from = Math.max(to - configDO.getEntrustNum(), 0);
        buyPriceLine = lines.subList(from,to);
        buyPriceLine.forEach(this::openBuy);

        for(int i = from - 50; i < from ; i++ ){

            if(i > 0 && i < lineSize){
                realCancel(lines.get(i));
            }
        }
    }



    private boolean load(){

        List<GridOrderDO> gridOrders = orderService.getLoad(configDO);

        boolean empty = gridOrders.isEmpty();

        log.info("load empty:{}",empty);
        if(empty){
            return false;
        }

        log.info("load gridOrders.size:{}", gridOrders.size());


        gridOrders.forEach(self->{

            PriceLine priceLine = getPriceLineSub(self);

            if(Constant.BUY.equals(self.getTrendType()) ){

                priceLine.buyOrder = self;

                PriceLine headBuy = headBuyRef.get();
                if(headBuy == null || priceLine.buyPrice.compareTo(headBuy.buyPrice) > 0){
                    headBuyRef.set(priceLine);
                }

            }else{

                sellOrderSize.getAndIncrement();

                PriceLine lastSell = lastSellRef.get();
                if(lastSell == null || priceLine.sellPrice.compareTo(lastSell.sellPrice) < 0 ){
                    lastSellRef.set(priceLine);
                }

                PriceLine headSell = headSellRef.get();
                if(headSell == null || priceLine.sellPrice.compareTo(headSell.sellPrice) > 0 ){
                    headSellRef.set(priceLine);
                }
            }
        });




        long count = orderService.getGridOrderDao().selectCount(Wrappers.lambdaQuery(GridOrderDO.class)
                .eq(GridOrderDO::getConfigId,configId)
                .eq(GridOrderDO::getSellLoad,Constant.Order_Load));
        shelveOrderSize.set((int) count);


        rangePin(configDO.getStartPrice());

        return true;
    }



    /**
     * 当前区间信息
     */
    private void currentRange() {

        PriceLine headBuy = headBuyRef.get();
        if(headBuy == null) {
            return;
        }

        ConfigInfo configInfo = configStatus.getConfigInfo();
        configInfo.setRangeIndex(headBuy.range);

        lines.stream().filter(self->self.range == headBuy.range).map(self->self.buyPrice).max(BigDecimal::compareTo)
                .ifPresent(configInfo::setRangeStart);

        lines.stream().filter(self->self.range == headBuy.range).map(self->self.buyPrice).min(BigDecimal::compareTo)
                .ifPresent(configInfo::setRangeEnd);
    }

    /**
     * 买单首次成交 没有卖单 use || load加载
     * @param startPrice 起始价格
     */
    private void rangePin(BigDecimal startPrice){

        if(startPrice == null || sellOrderSize.get() > 0){
            return;
        }
        log.info("rangePin startPrice:{}", startPrice);

        // 区间确定 起始价格确定
        startPriceRef.set(startPrice);

        GridConfigDO update = new GridConfigDO();
        update.setStartPrice(startPrice);
        update.setId(configId);
        configService.update(update);

        ConfigInfo configInfo = configStatus.getConfigInfo();
        configInfo.setStartPrice(startPrice);

        PriceLine currentPriceLine = getPriceBuy(startPrice);
        int rangeNum = configDO.getRangeNum();

        lines.forEach(self->self.range=0);

        int size = 1;
        for(int i = currentPriceLine.index; i >= 0 ; i--){

            lines.get(i).range = ((size-1)/rangeNum) + 1;
            size++;
        }

/*
        size = -1;
        for(int i = currentPriceLine.index + 1; i < lines.size() ; i++){

            lines.get(i).range = ((Math.abs(size)-1)/rangeNum) + 1;
            size--;
        }
*/

    }

    static final String First_Loss = "first_loss";


    /** 利润结算 */
    private void settleProfit(GridOrderDO sell){

        BigDecimal sellAmt = sell.filledAmt();
        int parSize = 1;

        boolean firstLoss = First_Loss.equals(sell.getType());
        GridOrderDO buy = orderService.get(sell.getPairId());
        BigDecimal buyAmt = buy.filledAmt();

        BigDecimal pairProfit =  sellAmt.subtract(buyAmt);

        synchronized (configStatus){
            if(firstLoss){
                configStatus.setLossSize(configStatus.getLossSize() + 1);
                configStatus.setLossProfit(configStatus.getLossProfit().add(pairProfit));
            }else{
                configStatus.setPairSize(configStatus.getPairSize() + parSize);
                configStatus.setPairProfit(configStatus.getPairProfit().add(pairProfit));
                configStatus.setLossProfit(configStatus.getLossProfit().add(pairProfit));
            }

            saveConfigStatus();
        }
    }

    private void saveConfigStatus(){
        synchronized (configStatus) {

            GridConfigDO configDO = new GridConfigDO();
            configDO.setId(configId);
            configDO.setStatusConfig(JSONUtils.beanToJson(configStatus));
            configService.update(configDO);
        }
    }

    private void clearConfigStatus() {
        configStatus.setLossProfit(BigDecimal.ZERO);
        configStatus.setPairProfit(BigDecimal.ZERO);
        configStatus.setPairSize(0);
        configStatus.setTotalProfit(BigDecimal.ZERO);
        configStatus.setConfigInfo(new ConfigInfo());
        synchronized (configStatus) {

            GridConfigDO configDO = new GridConfigDO();
            configDO.setId(configId);
            configDO.setStatusConfig(JSONUtils.beanToJson(configStatus));
            configService.update(configDO);
        }

    }

    /**
     * 挂单维护
     */
    private void sellRangeMaintain(){

        if(!sellFails.isEmpty()){

            BigDecimal sellPrice = sellPriceRef.get();
            if(sellPrice == null){
                return;
            }

            List<GridOrderDO> sellFailTmp = Lists.newArrayList(sellFails);

            // 当前价格 100块   可以挂单110块
            // 要挂单110 现在120 挂130块
            List<Long> buyIds = sellFailTmp.stream().map(GridOrderDO::getId).collect(Collectors.toList());
            List<GridOrderDO> gridOrderDOS = orderService.getGridOrderDao().selectBatchIds(buyIds);

            for (GridOrderDO buyOrder : gridOrderDOS) {

                PriceLine priceLineSub = getPriceLineSub(buyOrder);
                log.info("卖单失败 重新挂单 buyOrder.id:{} index:{}",buyOrder.getId(),priceLineSub.index);
                openSell(priceLineSub,buyOrder);
            }
            sellFails.removeIf(self->buyIds.contains(self.getId()));
        }
    }


    /**
     * 首单止损  亏 X 盈利 x*N
     */
    private boolean firstLoss(){

        PriceLine headBuy = headBuyRef.get();
        PriceLine lastSell = lastSellRef.get();

        if(headBuy == null || lastSell == null) {
            return false;
        }

        GridOrderDO sellFirst = getHeadSell();
        if(sellFirst == null){
            return false;
        }

        BigDecimal sellAmt = sellFirst.entrustAmt();
        BigDecimal sellPrice = sellPriceRef.get();
        if(buyPriceRef.get() == null){
            return false;
        }

        // 跌幅
        BigDecimal fall = sellFirst.fall(sellPrice);
        BigDecimal fallSell = sellAmt.multiply(fall);
        // 可以补偿金额
        BigDecimal compensateAmt = configStatus.getLossProfit().multiply(otherConfig.getCompensate());

        ConfigInfo configInfo = configStatus.getConfigInfo();
        configInfo.setFirstAmt(fallSell);
        configInfo.setFirstFall(fall);
        configInfo.setCompensateAmt(compensateAmt);

        boolean b = fall.compareTo(otherConfig.getHeadOrderFall()) >= 0;
        boolean c = compensateAmt.compareTo(fallSell) >= 0;

        log.info("首单止损 跌幅:{} 亏损:{} 可补:{} set.fall:{} set.comp:{}\r\nb:{} c:{}",fall,fallSell,compensateAmt,otherConfig.getHeadOrderFall(),otherConfig.getCompensate(),b,c);
        if (b && c) {


            GridOrderDO update = new GridOrderDO();
            update.setType(First_Loss);
            update.setId(sellFirst.getId());
            orderService.update(update);

            PriceLine sellHead = getPriceLineSub(sellFirst);
            if(!Constant.Order_Cancel.equals(sellFirst.getStatus())){

                cancelOrderReq(sellFirst.getClientId());
                int i = 0;
                for(;;){
                    GridOrderDO gridOrderDO = orderService.get(sellFirst.getId());
                    if(i > 10 || Constant.Order_Cancel.equals(gridOrderDO.getStatus())){
                        break;
                    }
                    i++;
                    try {
                        TimeUnit.MILLISECONDS.sleep(100);
                    } catch (InterruptedException ignored) {
                    }
                }
            }
            log.info("首单 市价平仓 sellHead.index：{} price:{}",sellHead.index,sellFirst.getEntrustPrice());
            // 首单 市价平仓
            openOrderMaker(sellFirst.getEntrustNumber(), sellFirst.getClientId());

            int i=0;
            for(;;){

                GridOrderDO gridOrderDO = orderService.get(sellFirst.getId());
                if(i > 10 || Constant.Order_Filled.equals(gridOrderDO.getStatus())){
                    log.info("首单 市价成交 filledPrice:{}",gridOrderDO.getFilledPrice());
                    break;
                }
                i++;
                try {
                    TimeUnit.MILLISECONDS.sleep(500);
                } catch (InterruptedException ignored) {
                }
            }
            if(i > 10){
                log.error("首次止损没有市价成交 clientId:{}",sellFirst.getClientId());
            }
        }
        return b && c;
    }

    /** 卖单挂单数量限制*/
    private void sellRangeCheck() {

        if(!Constant.YES.equals(configDO.getCancelType())) {
            return;
        }

        int sellRangeSize = sellOrderSize.get();
        if(sellRangeSize > Sell_Size) {

            GridOrderDO headSellPending = getHeadSellPending();
            cancelOrderReq(headSellPending.getClientId());

            sellOrderSize.getAndDecrement();
            shelveOrderSize.getAndIncrement();


            GridOrderDO update = new GridOrderDO();
            update.setId(headSellPending.getId());
            update.setSellLoad(Constant.Order_Load);
            orderService.update(update);
            log.info("sellRangeCheck sellRangeSize:{} remove.id:{} price:{}",sellRangeSize,headSellPending.getId(),headSellPending.getEntrustPrice());
            return;
        }

        if(sellRangeSize < (Sell_Size - 4) && shelveOrderSize.get() > 0) {

            GridOrderDO shelveLast = getShelveLast();

            openOrderReq(SIDE.SELL, shelveLast.getEntrustPrice(), shelveLast.getEntrustNumber(), shelveLast.getClientId());
            shelveOrderSize.getAndDecrement();

            GridOrderDO update = new GridOrderDO();
            update.setId(shelveLast.getId());
            update.setSellLoad(Constant.Blank);
            orderService.update(update);

            log.info("sellRangeCheck sellRangeSize:{} shelveOrderSize:{} add.id:{} price:{}",sellRangeSize,shelveOrderSize.get(),shelveLast.getId(),shelveLast.getEntrustNumber());
        }

    }

    /** 多卖单还原*/
    private void upLineOrderHandle(){

        if(upLineOrder.isEmpty()){
            return;
        }

        BigDecimal sellPrice = sellPriceRef.get();
        if(sellPrice == null){
            return;
        }

        List<GridOrderDO> cancelOrders = upLineOrder.stream().filter(self -> getPriceLineSub(self).sellPrice.compareTo(sellPriceRef.get()) > 0).collect(Collectors.toList());

        List<Long> cancelIds = Lists.newArrayList();

        for (GridOrderDO buyOrder : cancelOrders) {

            GridOrderDO sellOrder = orderService.getSellOrderByPairId(buyOrder);
            PriceLine buyPriceLine = getPriceLineSub(buyOrder);

            if(sellOrder != null && buyPriceLine.sellPrice.compareTo(sellPriceRef.get()) > 0){

                cancelOrderReq(sellOrder.getClientId());

                for (int i = 0; i < 10 ; i++){

                    try {
                        TimeUnit.MILLISECONDS.sleep(100);
                    } catch (InterruptedException ignored) {
                    }

                    GridOrderDO gridOrderDO = orderService.get(sellOrder.getId());

                    if(Constant.Order_Cancel.equals(gridOrderDO.getStatus())){
                        log.info("多卖单还原 buyOrder.id:{} index:{} 原来sellOrder.id:{} clientId:{}",buyOrder.getId(),buyPriceLine.index,sellOrder.getId(),sellOrder.getClientId());
                        sellOrderSize.getAndDecrement();
                        cancelIds.add(buyOrder.getId());

                        openSell(getPriceLineSub(gridOrderDO),gridOrderDO);

                    }
                }
            }

        }

        upLineOrder.removeIf(self->cancelIds.contains(self.getId()));


    }

    /** 卖单 价格最高 挂单 与 搁置单 */
    private GridOrderDO getHeadSell(){

        return orderService.getGridOrderDao().selectOne(Wrappers.lambdaQuery(GridOrderDO.class)
                .eq(GridOrderDO::getId,configId)
                .eq(GridOrderDO::getTrendType,Constant.SELL)
                .and(wrapper->wrapper.eq(GridOrderDO::getStatus,Constant.Order_NEW).or().eq(GridOrderDO::getSellLoad,Constant.Order_Load))
                .orderByDesc(GridOrderDO::getEntrustPrice).last("limit 1"));
    };

    /** 卖单 价格最高 挂单 */
    private GridOrderDO getHeadSellPending(){

        return orderService.getGridOrderDao().selectOne(Wrappers.lambdaQuery(GridOrderDO.class)
                .eq(GridOrderDO::getId,configId)
                .eq(GridOrderDO::getTrendType,Constant.SELL)
                .eq(GridOrderDO::getStatus,Constant.Order_NEW)
                .orderByDesc(GridOrderDO::getEntrustPrice).last("limit 1"));
    };

    private GridOrderDO getShelveLast(){

        return orderService.getGridOrderDao().selectOne(Wrappers.lambdaQuery(GridOrderDO.class)
                .eq(GridOrderDO::getId,configId)
                .eq(GridOrderDO::getTrendType,Constant.SELL)
                .eq(GridOrderDO::getStatus,Constant.Order_Cancel)
                .eq(GridOrderDO::getSellLoad,Constant.Order_Load)
                .orderByAsc(GridOrderDO::getEntrustPrice).last("limit 1"));
    }


    /**
     * 买单生成
     * @param priceLine 网格线
     */
    private void openBuy(PriceLine priceLine){

        if(priceLine.buyOrder != null){

            String status = priceLine.buyOrder.getStatus();
            if(Constant.Order_NEW.equals(status) || Constant.Order_Local.equals(status)){
                return;
            }
        }

        int range = priceLine.range;

        if(range < minRange){
            range = minRange;
        }
        if(range > maxRange){
            range = maxRange;
        }

        BigDecimal buyPrice = priceLine.buyPrice;
        BigDecimal singleAmt = configDO.getSingleAmt();
        RangeProDO rangeProDO = rangeProMap.get(range);
        BigDecimal totalAmt = singleAmt.multiply(rangeProDO.getProValue());


        BigDecimal qtyTick = symbolAccuracy.qtyTick;
        BigDecimal qyt = qtyTick;

        while (qyt.multiply(buyPrice).compareTo(totalAmt) < 0) {
            qyt = qyt.add(qtyTick);
        }

        log.info("openBuy 单次金额:{} 区间:{} 倍投:{} 倍投-Amt:{} qty:{} buyPrice:{}", singleAmt, rangeProDO.getRangeIndex(),rangeProDO.getProValue(),totalAmt,qyt,buyPrice);

        priceLine.buyQty = qyt;
        priceLine.buyOrder = realOpen(priceLine,null, SIDE.BUY);
    }

    /**
     * 卖单生成
     * @param priceLine 成交的买单
     */
    private void openSell(PriceLine priceLine,GridOrderDO buyOrder){
       realOpen(priceLine, buyOrder, SIDE.SELL);
    }


    public PriceLine getPriceBuy(BigDecimal price){
        BigDecimal key = price.setScale(symbolAccuracy.priceAccuracy(), RoundingMode.DOWN);
        return buyLines.get(key);
    }

    public PriceLine getPriceSell(BigDecimal price){
        BigDecimal key = price.setScale(symbolAccuracy.priceAccuracy(), RoundingMode.DOWN);
        return sellLines.get(key);
    }


    public PriceLine getPriceLineSub(GridOrderDO gridOrder){

        BigDecimal key = gridOrder.getEntrustPrice().setScale(symbolAccuracy.priceAccuracy(), RoundingMode.HALF_UP);

        if(Constant.BUY.equals(gridOrder.getTrendType())){
            return  buyLines.get(key);
        }
        return  sellLines.get(key);
    }

    public PriceLine getCurrentPriceLine(BigDecimal price){

        PriceLine current = null;
        int size = lines.size();
        try {
            for (PriceLine priceLine : lines) {
                if (price.compareTo(priceLine.buyPrice) >= 0 && price.compareTo(priceLine.sellPrice) < 0) {
                    current = priceLine;
                }
            }
            return current;
        } finally {
            log.info("getCurrentPriceLine param price:{} size:{} current:{}",price,size, current == null ? null : current.buyPrice);
        }
    }

    private SymbolAccuracy getSymbolAccuracyInfo(String symbol) {

        Market market = Constant.spotClient.createMarket();

        Map<String, Object> parameters = Maps.newHashMap();
        parameters.put("symbol",symbol);
        String exchangeInfo = market.exchangeInfo(parameters);
        JSONObject jsonObject = new JSONObject(exchangeInfo);
        JSONArray symbols = jsonObject.getJSONArray("symbols");
        if(symbols.length() != 1){
            throw  new RuntimeException("exchangeInfo-symbol:"+symbol + " 没找到");
        }

        JSONArray filters = symbols.getJSONObject(0).getJSONArray("filters");

        Optional<JSONObject> priceFilter = StreamSupport.stream(filters.spliterator(), false)
                .map(self -> (JSONObject) self)
                .filter(self -> "PRICE_FILTER".equals(self.getString("filterType")))
                .findFirst();

        Optional<JSONObject> lotSize = StreamSupport.stream(filters.spliterator(), false)
                .map(self -> (JSONObject) self)
                .filter(self -> "LOT_SIZE".equals(self.getString("filterType")))
                .findFirst();

        JSONObject PRICE_FILTER = priceFilter.orElseThrow(() -> new RuntimeException("symbol - PRICE_FILTER 找不到" + symbol));
        JSONObject LOT_SIZE = lotSize.orElseThrow(() -> new RuntimeException("symbol - LOT_SIZE 找不到" + symbol));
//
        BigDecimal priceTick = PRICE_FILTER.getBigDecimal("tickSize").stripTrailingZeros();

        BigDecimal qtyTick = LOT_SIZE.getBigDecimal("stepSize").stripTrailingZeros();

        return new SymbolAccuracy(priceTick,qtyTick);
    }


    public List<PriceLine> generateLine(){

        // true  均利  按最低利润率获取买入卖出线
        // false 均价  按价格间距获取买入卖出线
        boolean gridType = Constant.YES.equals( configDO.getGridType());

        BigDecimal gridValue = configDO.getGridValue();
        BigDecimal minPrice = configDO.getMinPrice();
        BigDecimal maxPrice = configDO.getMaxPrice();

        List<PriceLine> lineList = Lists.newArrayList();
        int index = 0;

        BigDecimal priceTick = symbolAccuracy.priceTick;

        BigDecimal buyPrice = symbolAccuracy.priceTick;
        BigDecimal sellPrice = symbolAccuracy.priceTick;

        while (buyPrice.compareTo(maxPrice) <= 0) {

            if (gridType) {

                while (sellPrice.subtract(buyPrice).divide(buyPrice, 8, RoundingMode.HALF_UP).compareTo(gridValue) < 0) {
                    sellPrice = sellPrice.add(priceTick);
                }
            } else {
                sellPrice = sellPrice.add(gridValue);
            }

            if (buyPrice.compareTo(minPrice) >= 0) {

                PriceLine priceLine = new PriceLine(index, buyPrice, sellPrice);
                lineList.add(priceLine);
                buyLines.put(priceLine.buyPrice, priceLine);
                sellLines.put(priceLine.sellPrice, priceLine);
                index++;
            }
            buyPrice = sellPrice;
        }
        log.info("generateLine - lineList:{}",lineList.size());
        return lineList;
    }

    public GridOrderDO realOpen(PriceLine priceLine,GridOrderDO buyOrder,SIDE side){

        boolean isBuy = SIDE.BUY == side;
        String clientOrderId = Constant.getClientOrderId();

        BigDecimal price = isBuy ? priceLine.buyPrice : priceLine.sellPrice;

        BigDecimal number = isBuy ? priceLine.buyQty : buyOrder.getFilledNumber();

        BigDecimal sellPrice = sellPriceRef.get();
        if(!isBuy && sellPrice != null){

            // 卖单价格设置   当前卖出 价格< 最新卖出价格
            if(price.compareTo(sellPriceRef.get()) < 0){

                for(int i = priceLine.index + 1; i < lineSize; i++){

                    PriceLine priceLine1 = lines.get(i);

                    if(priceLine1.sellPrice.compareTo(sellPriceRef.get()) > 0){
                        price = priceLine1.sellPrice;
                        log.info("卖单多挂格子 index:{} price:{}",priceLine1.index,priceLine1.sellPrice);
                        break;
                    }
                }
            }
        }

        openOrderReq(side,price,number,clientOrderId);

        GridOrderDO gridOrder = new GridOrderDO();
        gridOrder.setConfigId(configId);
        gridOrder.setCode(configDO.getCode());
        gridOrder.setSymbol(symbol);
        gridOrder.setTrendType(side.toString());
        gridOrder.setClientId(clientOrderId);
        gridOrder.setEntrustPrice(price);
        gridOrder.setEntrustNumber(number);
        gridOrder.setEntrustTime(LocalDateTime.now());
        gridOrder.setStatus(Constant.Order_Local);
        if(!isBuy){
            gridOrder.setPairId(buyOrder.getId());
        }
        orderService.save(gridOrder);
        log.info("realOpen index:{} range:{} side:{} price:{} clientId:{}\r\n{}", priceLine.index,priceLine.range,side,price,clientOrderId,JSONUtils.beanToJson(gridOrder));
        return gridOrder;
    }

    public void realCancel(PriceLine priceLine){

        GridOrderDO gridOrder = priceLine.buyOrder;
        if(gridOrder == null || !Constant.orderNew(gridOrder.getStatus())){
            return;
        }

        log.info("realCancel index:{} range:{} side:{} price:{} clientId:{}\r\n{}", priceLine.index,priceLine.range,gridOrder.getTrendType(),gridOrder.getEntrustPrice(),gridOrder.getClientId(),JSONUtils.beanToJson(gridOrder));

        cancelOrderReq(gridOrder.getClientId());
    }


    /// SPOT - WebSocketAPI

    private final Map<String, String> requestIdClientId = Maps.newConcurrentMap();
    private final Map<String, Consumer<com.alibaba.fastjson2.JSONObject>> callbackMethod = Maps.newConcurrentMap();

    private String getRequestId(Consumer<com.alibaba.fastjson2.JSONObject> callback,String clientId){

        while (true){
            String simpleUUID = IdUtil.fastSimpleUUID();

            if( !callbackMethod.containsKey(simpleUUID)){
                callbackMethod.put(simpleUUID, callback);
                requestIdClientId.put(simpleUUID, clientId);
                return simpleUUID;
            }
        }
    }

    /**
     * 下单
     * @param side 方向
     * @param price 价格
     * @param quantity 数量
     * @param clientId clientId
     */
    private void openOrderReq(SIDE side, BigDecimal price, BigDecimal quantity, String clientId){

        String symbol = this.symbol;
        String sideStr = side.toString();
        String type = SpotGridManager.ENV ? "LIMIT_MAKER" : "LIMIT";

        JSONObject parameters = new JSONObject();
        parameters.put("price",price.stripTrailingZeros().toPlainString());
        parameters.put("quantity",quantity.stripTrailingZeros().toPlainString());
        parameters.put("newClientOrderId",clientId);
        if(SpotGridManager.ENV == false) {
            parameters.put("timeInForce", "GTC");
        }
        String requestId = getRequestId(this::onOpenOrder,clientId);
        parameters.put("requestId", requestId);

        trade.newOrder(symbol,sideStr,type,parameters);

        log.info("openOrder requestId:{} parameters:{}",requestId,parameters);
    }

    /**
     * 市价下单
     * @param quantity 数量
     * @param clientId clientId
     */
    private void openOrderMaker(BigDecimal quantity,String clientId){


        String symbol = this.symbol;
        String type = "MARKET";

        JSONObject parameters = new JSONObject();
        parameters.put("quantity",quantity.stripTrailingZeros().toPlainString());
        parameters.put("newClientOrderId",clientId);
        String requestId = getRequestId(this::onOpenOrder,clientId);
        parameters.put("requestId", requestId);

        trade.newOrder(symbol,"SELL",type,parameters);
        log.info("openOrderMaker requestId:{} parameters:{}",requestId,parameters);
    }



    public void orderFilled(GridOrderDO gridOrder){

        if(!running.get()){
            return;
        }


        // 买单成交  价格下跌
        if(Constant.BUY.equals(gridOrder.getTrendType())){

            final PriceLine priceLine= getPriceLineSub(gridOrder);
            priceLine.buyOrder = gridOrder;
            rangePin(priceLine.buyPrice);
            openSell(priceLine,gridOrder);
            currentRange();
        }

        // 卖单成交  价格上涨  计算盈利
        if(Constant.SELL.equals(gridOrder.getTrendType())){

            sellOrderSize.getAndDecrement();
            upLineOrder.removeIf(self->self.getId().equals(gridOrder.getPairId()));
            if(sellOrderSize.get() == 0){
                lastSellRef.set(null);
                headSellRef.set(null);
                return;
            }

            task.addFirst(()->{

                settleProfit(gridOrder);

                Map<String, BigDecimal> stringBigDecimalMap = orderService.getGridOrderDao().querySellPriceHeadLast(configId);

                BigDecimal sellLow = stringBigDecimalMap.get("sellLow");
                BigDecimal sellHigh = stringBigDecimalMap.get("sellHigh");
                if(sellLow != null){
                    lastSellRef.set(getPriceSell(sellLow));
                }
                if(sellHigh != null){
                    headSellRef.set(getPriceSell(sellHigh));
                }
            });
            LockSupport.unpark(master);
        }

        // 卖单失败 重新挂单
        sellRangeMaintain();
    }

    private void onOpenOrder(com.alibaba.fastjson2.JSONObject data){
        Constant.setMDC(mdc);

        com.alibaba.fastjson2.JSONObject result = data.getJSONObject("result");
        String clientOrderId = result.getString("clientOrderId");

        GridOrderDO gridOrder = orderService.getByClientId(clientOrderId);
        if (gridOrder == null) {
            return;
        }

        orderNew(gridOrder.getId(),result.getString("orderId"),clientOrderId);

        boolean isBuy = Constant.BUY.equals(gridOrder.getTrendType());
        PriceLine priceLine = getPriceLineSub(gridOrder);

        if(isBuy){
            priceLine.buyOrder.updateStatus(Constant.Order_Local,Constant.Order_NEW);
        }else{

            sellOrderSize.getAndIncrement();

            PriceLine lastSell = lastSellRef.get();
            if(lastSell == null){
                lastSellRef.set(priceLine);

            }else if(priceLine.sellPrice.compareTo(lastSell.sellPrice) < 0 ){
                lastSellRef.compareAndSet(lastSell,priceLine);
            }

        }
    }


    private void cancelOrderReq(String clientId){

        String symbol = this.symbol;
        JSONObject parameters = new JSONObject();
        parameters.put("origClientOrderId",clientId);
        String requestId = getRequestId(this::onCancelOrder,clientId);
        parameters.put("requestId", requestId);
        trade.cancelOrder(symbol,parameters );
        log.info("cancelOrder requestId:{} parameters:{}",requestId,parameters);
    }

    private void onCancelOrder(com.alibaba.fastjson2.JSONObject data){
        Constant.setMDC(mdc);

        com.alibaba.fastjson2.JSONObject result = data.getJSONObject("result");
        String clientOrderId = result.getString("origClientOrderId");
        GridOrderDO gridOrder = orderService.getByClientId(clientOrderId);

        String status = result.getString("status");
        if(Constant.Order_Cancel.equals(status)){

            orderCancel(gridOrder.getId(),clientOrderId);
            PriceLine priceLineSub = getPriceLineSub(gridOrder);

            boolean isBuy = Constant.BUY.equals(gridOrder.getTrendType());
            if(isBuy){
                priceLineSub.buyOrder.setStatus(Constant.Order_Cancel);
            }else{
                //.sellOrder.setStatus(Constant.Order_Cancel);
            }
            return;
        }
        log.error("onCancelOrder 撤单失败 clientOrderId：{} data:{}",clientOrderId,data);
    }

    private void onMessageRel(String data){

        Constant.setMDC(mdc);

        com.alibaba.fastjson2.JSONObject jsonObject = JSON.parseObject(data);
        String id = jsonObject.getString("id");
        Consumer<com.alibaba.fastjson2.JSONObject> jsonObjectConsumer = callbackMethod.remove(id);
        String clientId = requestIdClientId.remove(id);
        int status = jsonObject.getIntValue("status");
        if(status != 200){


/*            // 重试
            if(status == 1000 || status == 10001){

            }
            //请求过多
            if(status == 1003){

            }
            //服务器正忙，请稍候再试。
            if(status == 1004){

            }*/
            if(status == 400) {

                com.alibaba.fastjson2.JSONObject jsonObject2 = jsonObject.getJSONObject("error");
                int code = jsonObject2.getIntValue("code");
                // 委托挂单 时机错过
                if(code == -2010 && clientId != null) {

                    GridOrderDO byClientId = orderService.getByClientId(clientId);
                    if(byClientId != null) {

                        orderCancel(byClientId.getId(), clientId);

                        if(Constant.BUY.equals(byClientId.getTrendType())) {

                            PriceLine priceLine = getPriceLineSub(byClientId);
                            priceLine.buyOrder = null;
                        }else {

                            GridOrderDO buyOrder = orderService.get(byClientId.getPairId());
                            // sell 下单失败
                            sellFails.add(buyOrder);
                        }

                        log.info("委托挂单 时机错过 clientId:{}",clientId);
                        return;
                    }
                }
            }
            log.error("onMessage-{}",data);
            return;
        }

        try {
            if (jsonObjectConsumer != null){
                log.info("callback-requestId:{}",id);
                jsonObjectConsumer.accept(jsonObject);
            }
        } catch (Exception e) {
            log.error("callbackMethod-{}\r\njsonObject:{}",id,jsonObject,e);
        }

    }

    private void onClosing(int code, String reason){
        linkStatus.set(false);
    }
    private void onClosed(int code, String reason){
        Constant.setMDC(mdc);
        linkStatus.set(false);
        webSocketInfo.closeFlag = true;
        log.info("close-{}", JSONUtils.beanToJson(webSocketInfo));
        LockSupport.unpark(master);
    }
    private void onFailure(Throwable t, Response response){
        Constant.setMDC(mdc);

        webSocketInfo.failureSize++;
        log.error("onFailure",t);
    }

    private void orderNew(Long id,String orderId,String clientOrderId){

        GridOrderDO update = new GridOrderDO();
        update.setId(id);
        update.setOrderId(orderId);
        update.setStatus(Constant.Order_NEW);
        log.info("orderNew clientId:{} id:{} orderId:{}",clientOrderId,id,orderId);
        orderService.update(update);
    }

    private void orderCancel(Long id,String clientOrderId){

        GridOrderDO update = new GridOrderDO();
        update.setId(id);
        update.setStatus(Constant.Order_Cancel);
        update.setFilledTime(LocalDateTime.now());
        log.info("orderCancel clientId:{} id:{}",clientOrderId,id);
        orderService.update(update);
    }

    private void orderFilled(Long id,String clientOrderId,BigDecimal filledNumber,BigDecimal filledPrice){

        GridOrderDO update = new GridOrderDO();
        update.setId(id);
        update.setStatus(Constant.Order_Filled);
        update.setFilledNumber(filledNumber);
        update.setFilledPrice(filledPrice);
        update.setFilledTime(LocalDateTime.now());
        log.info("orderFilled clientId:{} id:{} filledNumber:{} filledPrice:{}",clientOrderId,id,filledNumber,filledPrice);
        orderService.update(update);

        orderFilled(orderService.get(id));
    }

    public void userDataNew(ApiTrackDO apiTrackDO, GridOrderDO byClientId){
        Constant.setMDC(mdc);
        log.info("userDataNew id:{} side:{} clientId:{}\r\napiTrackDO:{}",byClientId.getId(),byClientId.getTrendType(),byClientId.getClientId(),JSONUtils.beanToJson(apiTrackDO));
        orderNew(byClientId.getId(),apiTrackDO.getOrderId().toString(), byClientId.getClientId());

        if(Constant.SELL.equals(byClientId.getTrendType())){

            // 多卖格子 记录
            GridOrderDO buyOrder = orderService.get(byClientId.getPairId());
            PriceLine buyPriceLine = getPriceLineSub(buyOrder);
            PriceLine sellPriceLine = getPriceLineSub(byClientId);

            if(sellPriceLine.index > buyPriceLine.index){
                upLineOrder.add(buyOrder);
                log.info("格子多卖了  buyId:{} index:{} sellId:{} index:{}",buyOrder.getId(),buyPriceLine.index,byClientId.getId(),sellPriceLine.index);
            }

        }
    }

    public void userDataCancel(ApiTrackDO apiTrackDO, GridOrderDO byClientId){
        Constant.setMDC(mdc);
        log.info("userDataCancel id:{} side:{} clientId:{}\r\napiTrackDO:{}",byClientId.getId(),byClientId.getTrendType(),byClientId.getClientId(),JSONUtils.beanToJson(apiTrackDO));
        orderCancel(byClientId.getId(),byClientId.getClientId());
    }

    public void userDataFilled(ApiTrackDO apiTrackDO, GridOrderDO byClientId){
        Constant.setMDC(mdc);
        log.info("userDataFilled id:{} side:{} clientId:{}\r\napiTrackDO:{}",byClientId.getId(),byClientId.getTrendType(),byClientId.getClientId(),JSONUtils.beanToJson(apiTrackDO));

        orderFilled(byClientId.getId(),byClientId.getClientId(),apiTrackDO.getAccumulatedQuantity(),apiTrackDO.realAvgPrice());
    }


    private void connect(){
        webSocketInfo.connectTime = LocalDateTime.now();
        webSocketInfo.openFlag = false;
        webSocketInfo.closeFlag = false;
        webSocketInfo.timeoutFlag = false;
        webSocketInfo.reconnectSize++;

        apiClient.connect(this::onOpen,this::onMessage,this::onClosing,this::onClosed,this::onFailure);
        trade = apiClient.trade();

        log.info("connect-{}", JSONUtils.beanToJson(webSocketInfo));
    }


    private boolean webSocketStatus(){

        // 连接关闭
        if(webSocketInfo.openFlag && webSocketInfo.closeFlag){
            log.info("webSocket-status 重新连接：{}", JSONUtils.beanToJson(webSocketInfo));
            connect();
            return false;
        }

        // 连接超时
        if(!webSocketInfo.openFlag && !webSocketInfo.timeoutFlag && LocalDateTime.now().isAfter(webSocketInfo.connectTime.plus(webSocketInfo.waitConnectTime))){
            apiClient.close();
            webSocketInfo.timeoutFlag = true;
            log.info("webSocket-status 连接超时：{}", JSONUtils.beanToJson(webSocketInfo));
            return  false;
        }

        // 重新连接
        if(webSocketInfo.timeoutFlag && webSocketInfo.reconnectSize <= 10){
            connect();
            log.info("webSocket-status 连接超时-重新连接：{}", JSONUtils.beanToJson(webSocketInfo));
            return false;
        }

        if(webSocketInfo.openFlag && !webSocketInfo.closeFlag && !webSocketInfo.timeoutFlag){
            return true;
        }

        return false;


    }

    private void onOpen(Response response){

        Constant.setMDC(mdc);

        webSocketInfo.openFlag = true;
        webSocketInfo.reconnectSize = 0;
        log.info("open-{}",JSONUtils.beanToJson(webSocketInfo));

        if(headBuyRef.get() != null || lastSellRef.get() != null){
            return;
        }

        boolean load = load();
        linkStatus.set(true);
    }

    private void onMessage(String data){

        onMessageRel(data);

    }

    /// SPOT - WebSocketAPI


    @Getter
    @Setter
    static class WebSocketInfo {

        final Duration waitConnectTime = Duration.ofSeconds(3) ;

        LocalDateTime connectTime;

        int reconnectSize;

        int failureSize;

        boolean timeoutFlag;

        boolean openFlag;

        boolean closeFlag;
    }

    static class SymbolAccuracy{

        public SymbolAccuracy(BigDecimal priceTick, BigDecimal qtyTick) {

            this.priceTick = priceTick;
            this.qtyTick = qtyTick;
        }

        /**步进价格*/
        private final BigDecimal priceTick;


        public int priceAccuracy(){
            return priceTick.scale();
        }

        /**步进数量*/
        private final BigDecimal qtyTick;

        public int qtyAccuracy(){
            return qtyTick.scale();
        }

        /** 最低订单金额 */
        private BigDecimal minNotional;

        /** 最高订单金额 */
        private BigDecimal maxNotional;
    }

    public static class PriceLine{

        @Getter
        final int index;

        int range;

        final BigDecimal buyPrice;

        BigDecimal buyQty;

        final BigDecimal sellPrice;

        @Getter
        volatile GridOrderDO buyOrder;


        private PriceLine(int index, BigDecimal buyPrice, BigDecimal sellPrice) {
            this.index = index;
            this.buyPrice = buyPrice;
            this.sellPrice = sellPrice;
        }

    }
}

