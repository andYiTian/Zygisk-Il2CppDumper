package com.bootdo.spotgrid.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.bootdo.spotgrid.dao.GridConfigDao;
import com.bootdo.spotgrid.domain.GridConfigDO;
import com.bootdo.spotgrid.service.GridConfigService;



@Service
public class GridConfigServiceImpl implements GridConfigService {
	@Autowired
	private GridConfigDao gridConfigDao;
	
	@Override
	public GridConfigDO get(Long id){
		return gridConfigDao.selectById(id);
	}

	
	@Override
	public int save(GridConfigDO gridConfig){
		return gridConfigDao.insert(gridConfig);
	}
	
	@Override
	public int update(GridConfigDO gridConfig){
		return gridConfigDao.updateById(gridConfig);
	}
	
	@Override
	public int remove(Long id){
		return gridConfigDao.deleteById(id);
	}
	
	@Override
	public int batchRemove(Long[] ids){
		return gridConfigDao.deleteBatchIds(Stream.of(ids).collect(Collectors.toList()));
	}

	@Override
	public GridConfigDao getGridConfigDao() {
		return gridConfigDao;
	}
}
