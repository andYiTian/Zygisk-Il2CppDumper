package com.bootdo.spotgrid.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@TableName("spot_grid_range")
@Getter
@Setter
public class RangeProDO {

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    private Integer rangeIndex;

    private BigDecimal proValue;
}
