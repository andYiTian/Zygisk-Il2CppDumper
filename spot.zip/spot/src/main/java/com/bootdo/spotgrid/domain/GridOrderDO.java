package com.bootdo.spotgrid.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.bootdo.common.utils.StringUtils;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;


/**
 * 网格订单
 * 
 * @author dongdong
 * @email 111
 * @date 2024-09-18 23:07:06
 */
@TableName("spot_grid_order")
@Getter
@Setter
public class GridOrderDO implements Serializable {
	private static final long serialVersionUID = 1L;
	
	//
	@TableId(value = "id", type = IdType.AUTO)
	private Long id;
	//配置id
	private Long configId;
	//编码
	private String code;
	//币种
	private String symbol;
	//方向-buy/sell
	private String trendType;
	//clientId
	private String clientId;
	//orderId
	private String orderId;
	//委托价格
	private BigDecimal entrustPrice;
	//委托数量
	private BigDecimal entrustNumber;
	//委托时间
	private LocalDateTime entrustTime;
	//订单状态
	private String status;
	//卖单超出40单  存放
	private String sellLoad;
	//成交数量
	private BigDecimal filledNumber;
	//成交价格
	private BigDecimal filledPrice;
	//成交时间
	private LocalDateTime filledTime;
	// 手续费  市价单
	private BigDecimal fee;
	// 手续费 币种
	private String feeAsset;
	// 止损价格  市价单
	private BigDecimal lossPrice;
	// 直撤 多个sell id
	private String mergeIds;
	// 利润
	private BigDecimal profit;
	// 配对id sell 对应 buy
	private Long pairId;
	// 特殊类型
	private String type;
	//
	private LocalDateTime addTime;
	//
	private LocalDateTime updateTime;

	public boolean isMerge(){
		return StringUtils.isNotBlank(mergeIds);
	}

	/**
	 * 下跌比例
	 * @return
	 */
	public BigDecimal fall(BigDecimal currentPrice){
		return entrustPrice.subtract(currentPrice).divide(entrustPrice,4, RoundingMode.DOWN);
	}

	public BigDecimal entrustAmt(){
		return  entrustNumber.multiply(entrustPrice);
	}

	public BigDecimal filledAmt(){
		return filledNumber.multiply(filledPrice);
	}

}
