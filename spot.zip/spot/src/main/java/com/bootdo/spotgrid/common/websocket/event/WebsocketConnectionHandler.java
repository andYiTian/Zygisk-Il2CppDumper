package com.bootdo.spotgrid.common.websocket.event;

import com.bootdo.spotgrid.common.websocket.callback.WebsocketInterceptorCallback;
import com.bootdo.spotgrid.common.websocket.client.WebsocketClient;
import com.bootdo.spotgrid.common.websocket.event.scheduled.IntervalEvent;
import com.bootdo.spotgrid.common.websocket.event.scheduled.ScheduledTask;

import java.time.Duration;

/**
 * Reconnects or disconnects the client according to
 * {@link WebsocketClientConfiguration#getReconnectionInterval} and
 * {@link WebsocketClientConfiguration#getMaxReconnections}
 */
public class WebsocketConnectionHandler extends BaseWebsocketEventHandler {
    /**
     * @param websocketClient Websocket client.
     * @param callback        Callback.
     */
    public WebsocketConnectionHandler(WebsocketClient websocketClient, WebsocketInterceptorCallback<?> callback) {
        super(websocketClient, callback, "Connection failed", "Connection failed too many times");
    }

    public void run() {
        cancel();
        Duration reconnectionInterval = websocketClient.getConfiguration().getReconnectionInterval();
        Duration timeoutInterval = websocketClient.getConfiguration().getReconnectionInterval();
        int maxReconnection = websocketClient.getConfiguration().getMaxReconnections();

        ScheduledTask reconnectTask = () -> {

            callback.onFailure(timeoutException);
            if (eventHandler.isFinalTick()) {
                disconnect(timeoutInterval);
            } else {
                disconnect(Duration.ofSeconds(0));
                websocketClient.open();
            }
        };
        eventHandler = new IntervalEvent(reconnectionInterval, maxReconnection, reconnectTask);
    }
}
