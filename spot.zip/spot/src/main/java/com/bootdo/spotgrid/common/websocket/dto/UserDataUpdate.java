package com.bootdo.spotgrid.common.websocket.dto;

import com.bootdo.spotgrid.common.websocket.serialization.UserDataUpdateEventDeserializer;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * User data update event:
 * <ul>
 * <li>{@code outboundAccountPosition}: the change in account balances caused by
 * an event.</li>
 * <li>{@code executionReport}: whenever there is a trade or an order.</li>
 * <li>{@code balanceUpdate}: the change in account balance (delta).</li>
 * </ul>
 *
 * @param eventType                          Event type.
 * @param eventTime                          Timestamp.
 * @param outboundAccountPositionUpdateEvent Account update.
 * @param balanceUpdateEvent                 Balance update.
 * @param orderTradeUpdateEvent              Order trade update.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonDeserialize(using = UserDataUpdateEventDeserializer.class)
@Data
@AllArgsConstructor
public class UserDataUpdate {

    UserDataUpdateType eventType;
    Long eventTime;
    AccountUpdate outboundAccountPositionUpdateEvent;
    BalanceUpdate balanceUpdateEvent;
    OrderTradeUpdate orderTradeUpdateEvent;

}