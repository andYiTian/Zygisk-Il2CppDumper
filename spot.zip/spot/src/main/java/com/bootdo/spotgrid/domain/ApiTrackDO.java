package com.bootdo.spotgrid.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;


/**
 * 现货交易详情
 * 
 * @author dongdong
 * @email 111
 * @date 2024-09-18 23:07:06
 */
@TableName("spot_api_track")
public class ApiTrackDO implements Serializable {
	private static final long serialVersionUID = 1L;
	
	//
	@TableId(value = "id", type = IdType.AUTO)
	private Long id;
	//账号名称
	private String apiName;
	//事件类型
	private String eventType;
	//事件时间
	private LocalDateTime eventTime;
	//交易对
	private String symbol;
	//clientId
	private String clientId;
	//订单方向
	private String side;
	//订单类型
	private String type;
	//有效方式
	private String timeInForce;
	//订单原始数量
	private BigDecimal orgiginalQuantity;
	//订单原始价格
	private BigDecimal price;
	//事件执行类型
	private String executionType;
	//订单当前状态
	private String orderStatus;
	//订单被拒绝原因
	private String orderRejectReason;
	//orderId
	private Long orderId;
	//订单末次成交量
	private BigDecimal quantityLastFilledTrade;
	//订单累计已成交量
	private BigDecimal accumulatedQuantity;
	//订单末次成交价格
	private BigDecimal priceOfLastFilledTrade;
	//手续费数量
	private BigDecimal commission;
	//手续费资产类别
	private String commissionAsset;
	//成交时间
	private LocalDateTime orderTradeTime;
	//成交id
	private Long tradeId;
	//是否在订单薄上
	private String orderBook;
	//该成交是作为挂单成交吗
	private String pending;
	//订单创建时间
	private LocalDateTime orderCreationTime;
	//订单累计已成交金额
	private BigDecimal cumulativeQuoteQuantity;
	//订单末次成交金额
	private BigDecimal lastQuoteQuantity;
	//报价订单数量
	private BigDecimal quoteOrderQuantity;
	//原始数据
	private String orgData;
	//
	private LocalDateTime addTime;
	//
	private LocalDateTime updateTime;


	public BigDecimal realAvgPrice(){
		return cumulativeQuoteQuantity.divide(accumulatedQuantity, 10, RoundingMode.HALF_UP);
	}

	/**
	 * 设置：
	 */
	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * 获取：
	 */
	public Long getId() {
		return id;
	}
	/**
	 * 设置：账号名称
	 */
	public void setApiName(String apiName) {
		this.apiName = apiName;
	}
	/**
	 * 获取：账号名称
	 */
	public String getApiName() {
		return apiName;
	}
	/**
	 * 设置：事件类型
	 */
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	/**
	 * 获取：事件类型
	 */
	public String getEventType() {
		return eventType;
	}
	/**
	 * 设置：事件时间
	 */
	public void setEventTime(LocalDateTime eventTime) {
		this.eventTime = eventTime;
	}
	/**
	 * 获取：事件时间
	 */
	public LocalDateTime getEventTime() {
		return eventTime;
	}
	/**
	 * 设置：交易对
	 */
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	/**
	 * 获取：交易对
	 */
	public String getSymbol() {
		return symbol;
	}
	/**
	 * 设置：clientId
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	/**
	 * 获取：clientId
	 */
	public String getClientId() {
		return clientId;
	}
	/**
	 * 设置：订单方向
	 */
	public void setSide(String side) {
		this.side = side;
	}
	/**
	 * 获取：订单方向
	 */
	public String getSide() {
		return side;
	}
	/**
	 * 设置：订单类型
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * 获取：订单类型
	 */
	public String getType() {
		return type;
	}
	/**
	 * 设置：有效方式
	 */
	public void setTimeInForce(String timeInForce) {
		this.timeInForce = timeInForce;
	}
	/**
	 * 获取：有效方式
	 */
	public String getTimeInForce() {
		return timeInForce;
	}
	/**
	 * 设置：订单原始数量
	 */
	public void setOrgiginalQuantity(BigDecimal orgiginalQuantity) {
		this.orgiginalQuantity = orgiginalQuantity;
	}
	/**
	 * 获取：订单原始数量
	 */
	public BigDecimal getOrgiginalQuantity() {
		return orgiginalQuantity;
	}
	/**
	 * 设置：订单原始价格
	 */
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	/**
	 * 获取：订单原始价格
	 */
	public BigDecimal getPrice() {
		return price;
	}
	/**
	 * 设置：事件执行类型
	 */
	public void setExecutionType(String executionType) {
		this.executionType = executionType;
	}
	/**
	 * 获取：事件执行类型
	 */
	public String getExecutionType() {
		return executionType;
	}
	/**
	 * 设置：订单当前状态
	 */
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	/**
	 * 获取：订单当前状态
	 */
	public String getOrderStatus() {
		return orderStatus;
	}
	/**
	 * 设置：订单被拒绝原因
	 */
	public void setOrderRejectReason(String orderRejectReason) {
		this.orderRejectReason = orderRejectReason;
	}
	/**
	 * 获取：订单被拒绝原因
	 */
	public String getOrderRejectReason() {
		return orderRejectReason;
	}
	/**
	 * 设置：orderId
	 */
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	/**
	 * 获取：orderId
	 */
	public Long getOrderId() {
		return orderId;
	}
	/**
	 * 设置：订单末次成交量
	 */
	public void setQuantityLastFilledTrade(BigDecimal quantityLastFilledTrade) {
		this.quantityLastFilledTrade = quantityLastFilledTrade;
	}
	/**
	 * 获取：订单末次成交量
	 */
	public BigDecimal getQuantityLastFilledTrade() {
		return quantityLastFilledTrade;
	}
	/**
	 * 设置：订单累计已成交量
	 */
	public void setAccumulatedQuantity(BigDecimal accumulatedQuantity) {
		this.accumulatedQuantity = accumulatedQuantity;
	}
	/**
	 * 获取：订单累计已成交量
	 */
	public BigDecimal getAccumulatedQuantity() {
		return accumulatedQuantity;
	}
	/**
	 * 设置：订单末次成交价格
	 */
	public void setPriceOfLastFilledTrade(BigDecimal priceOfLastFilledTrade) {
		this.priceOfLastFilledTrade = priceOfLastFilledTrade;
	}
	/**
	 * 获取：订单末次成交价格
	 */
	public BigDecimal getPriceOfLastFilledTrade() {
		return priceOfLastFilledTrade;
	}
	/**
	 * 设置：手续费数量
	 */
	public void setCommission(BigDecimal commission) {
		this.commission = commission;
	}
	/**
	 * 获取：手续费数量
	 */
	public BigDecimal getCommission() {
		return commission;
	}
	/**
	 * 设置：手续费资产类别
	 */
	public void setCommissionAsset(String commissionAsset) {
		this.commissionAsset = commissionAsset;
	}
	/**
	 * 获取：手续费资产类别
	 */
	public String getCommissionAsset() {
		return commissionAsset;
	}
	/**
	 * 设置：成交时间
	 */
	public void setOrderTradeTime(LocalDateTime orderTradeTime) {
		this.orderTradeTime = orderTradeTime;
	}
	/**
	 * 获取：成交时间
	 */
	public LocalDateTime getOrderTradeTime() {
		return orderTradeTime;
	}
	/**
	 * 设置：成交id
	 */
	public void setTradeId(Long tradeId) {
		this.tradeId = tradeId;
	}
	/**
	 * 获取：成交id
	 */
	public Long getTradeId() {
		return tradeId;
	}
	/**
	 * 设置：是否在订单薄上
	 */
	public void setOrderBook(String orderBook) {
		this.orderBook = orderBook;
	}
	/**
	 * 获取：是否在订单薄上
	 */
	public String getOrderBook() {
		return orderBook;
	}
	/**
	 * 设置：该成交是作为挂单成交吗
	 */
	public void setPending(String pending) {
		this.pending = pending;
	}
	/**
	 * 获取：该成交是作为挂单成交吗
	 */
	public String getPending() {
		return pending;
	}
	/**
	 * 设置：订单创建时间
	 */
	public void setOrderCreationTime(LocalDateTime orderCreationTime) {
		this.orderCreationTime = orderCreationTime;
	}
	/**
	 * 获取：订单创建时间
	 */
	public LocalDateTime getOrderCreationTime() {
		return orderCreationTime;
	}
	/**
	 * 设置：订单累计已成交金额
	 */
	public void setCumulativeQuoteQuantity(BigDecimal cumulativeQuoteQuantity) {
		this.cumulativeQuoteQuantity = cumulativeQuoteQuantity;
	}
	/**
	 * 获取：订单累计已成交金额
	 */
	public BigDecimal getCumulativeQuoteQuantity() {
		return cumulativeQuoteQuantity;
	}
	/**
	 * 设置：订单末次成交金额
	 */
	public void setLastQuoteQuantity(BigDecimal lastQuoteQuantity) {
		this.lastQuoteQuantity = lastQuoteQuantity;
	}
	/**
	 * 获取：订单末次成交金额
	 */
	public BigDecimal getLastQuoteQuantity() {
		return lastQuoteQuantity;
	}
	/**
	 * 设置：报价订单数量
	 */
	public void setQuoteOrderQuantity(BigDecimal quoteOrderQuantity) {
		this.quoteOrderQuantity = quoteOrderQuantity;
	}
	/**
	 * 获取：报价订单数量
	 */
	public BigDecimal getQuoteOrderQuantity() {
		return quoteOrderQuantity;
	}
	/**
	 * 设置：原始数据
	 */
	public void setOrgData(String orgData) {
		this.orgData = orgData;
	}
	/**
	 * 获取：原始数据
	 */
	public String getOrgData() {
		return orgData;
	}
	/**
	 * 设置：
	 */
	public void setAddTime(LocalDateTime addTime) {
		this.addTime = addTime;
	}
	/**
	 * 获取：
	 */
	public LocalDateTime getAddTime() {
		return addTime;
	}
	/**
	 * 设置：
	 */
	public void setUpdateTime(LocalDateTime updateTime) {
		this.updateTime = updateTime;
	}
	/**
	 * 获取：
	 */
	public LocalDateTime getUpdateTime() {
		return updateTime;
	}
}
