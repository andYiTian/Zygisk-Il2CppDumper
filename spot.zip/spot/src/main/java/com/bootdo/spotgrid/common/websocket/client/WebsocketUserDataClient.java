package com.bootdo.spotgrid.common.websocket.client;

import com.binance.connector.client.impl.spot.UserData;
import com.bootdo.common.utils.JSONUtils;
import com.bootdo.spotgrid.common.websocket.callback.WebsocketCallback;
import com.bootdo.spotgrid.common.websocket.dto.UserDataUpdate;
import com.bootdo.spotgrid.common.websocket.exception.ApiException;
import com.google.common.collect.Maps;
import org.json.JSONObject;

import java.time.Duration;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

/** Websocket client handling user data / balance events */
public class WebsocketUserDataClient extends BaseWebsocketClient<UserDataUpdate> {
    /** The inner user data client. */
    final UserData userDataClient;
    /** The timer responsible to schedule the keep alive task. */
    Timer timer;
    /** The keep alive task schedule interval. Default 30 minutes. */
    Duration keepAliveInterval = Duration.ofMinutes(30);

    /**
     * @param client   {@link UserData} that will fetch the listen key to open
     *                 the stream and keep it alive at a periodical interval.
     * @param callback Callback.
     * @throws ApiException Will be thrown if the client is unable to fetch the
     *                      listen key
     */
    public WebsocketUserDataClient(UserData client, WebsocketCallback<UserDataUpdate> callback) {
        super(null, convert(client.createListenKey()), UserDataUpdate.class, callback);
        userDataClient = client;
    }

    private static String convert(String data){
        return new JSONObject(data).getString("listenKey");
    }

    @Override
    public void open() {
        super.open();
        // let's start the keep alive task
        timer = new Timer();
        timer.schedule(new KeepAliveTask(), keepAliveInterval.toMillis(), keepAliveInterval.toMillis());
    }

    @Override
    public void close() {
        super.close();
        // let's stop the keep alive task
        timer.cancel();
    }

    /** The task responsible of keeping alive the listenKey. */
    private class KeepAliveTask extends TimerTask {
        @Override
        public void run() {
            Map<String, Object> parameters = Maps.newLinkedHashMap();
            parameters.put("listenKey",stream);
            userDataClient.extendListenKey(parameters);
        }
    }

    /**
     * @return the timer
     */
    public Timer getTimer() {
        return timer;
    }

    /**
     * @return the keepAliveInterval
     */
    public Duration getKeepAliveInterval() {
        return keepAliveInterval;
    }

    /**
     * @return The listen key the client is watching.
     */
    public String getListenKey() {
        return stream;
    }
}
