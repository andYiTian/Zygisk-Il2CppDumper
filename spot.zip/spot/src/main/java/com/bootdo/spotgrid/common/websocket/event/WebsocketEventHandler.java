package com.bootdo.spotgrid.common.websocket.event;

import java.time.Duration;

/** Base of any websocket event handler */
public interface WebsocketEventHandler {
    /** Rune the handler */
    void run();

    /** Cancel the handler */
    void cancel();

    /**
     * 断开 websocket 的连接。
     *
     * @param timeout Timeout to disconnect the handler.
     */
    void disconnect(Duration timeout);
}