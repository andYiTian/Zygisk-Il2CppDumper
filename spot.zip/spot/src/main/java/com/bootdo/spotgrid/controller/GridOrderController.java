package com.bootdo.spotgrid.controller;

import java.util.Map;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.bootdo.spotgrid.dao.GridOrderDao;
import com.bootdo.spotgrid.service.grid.SpotGridManager;
import com.bootdo.spotgrid.service.grid.SpotGridOrder;
import com.google.common.collect.Maps;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bootdo.spotgrid.domain.GridOrderDO;
import com.bootdo.spotgrid.service.GridOrderService;
import com.bootdo.common.utils.PageUtils;
import com.bootdo.common.utils.Query;
import com.bootdo.common.utils.R;

/**
 * 网格订单
 * 
 * @author dongdong
 * @email 111
 * @date 2024-09-18 23:07:06
 */
 
@Controller
@RequestMapping("/spotgrid/gridOrder")
public class GridOrderController {
	@Autowired
	private GridOrderService gridOrderService;

	@Autowired
	private GridOrderDao gridOrderDao;

	@Autowired
	private SpotGridManager gridManager;

	@GetMapping()
	@RequiresPermissions("spotgrid:gridOrder:gridOrder")
	String GridOrder(){
	    return "spotgrid/gridOrder/gridOrder";
	}
	
	@ResponseBody
	@GetMapping("/list")
	@RequiresPermissions("spotgrid:gridOrder:gridOrder")
	public PageUtils list(@RequestParam Map<String, Object> params){
		//查询列表数据
		Query query = new Query(params);
		IPage<GridOrderDO> page = gridOrderDao.selectPage(Page.of(query.getPage(), query.getLimit()),null);
		return PageUtils.returnPage(page);
	}

	@ResponseBody
	@PostMapping("getPendingOrder")
	@RequiresPermissions("spotgrid:gridOrder:gridOrder")
	public Map<String,Object> getPendingOrder(){

		SpotGridOrder gridOrder = gridManager.getGridOrder();

		Map<String,Object> map = Maps.newHashMap();
		map.put("sell",gridOrder.getSellCompleteRange());
		map.put("buy",gridOrder.getBuyCompleteRange());
		map.put("configStatus", gridOrder.getConfigStatus());
		return map;
	}
	
	@GetMapping("/add")
	@RequiresPermissions("spotgrid:gridOrder:add")
	String add(){
	    return "spotgrid/gridOrder/add";
	}

	@GetMapping("/edit/{id}")
	@RequiresPermissions("spotgrid:gridOrder:edit")
	String edit(@PathVariable("id") Long id,Model model){
		GridOrderDO gridOrder = gridOrderService.get(id);
		model.addAttribute("gridOrder", gridOrder);
	    return "spotgrid/gridOrder/edit";
	}
	
	/**
	 * 保存
	 */
	@ResponseBody
	@PostMapping("/save")
	@RequiresPermissions("spotgrid:gridOrder:add")
	public R save( GridOrderDO gridOrder){
		if(gridOrderService.save(gridOrder)>0){
			return R.ok();
		}
		return R.error();
	}
	/**
	 * 修改
	 */
	@ResponseBody
	@RequestMapping("/update")
	@RequiresPermissions("spotgrid:gridOrder:edit")
	public R update( GridOrderDO gridOrder){
		gridOrderService.update(gridOrder);
		return R.ok();
	}
	
	/**
	 * 删除
	 */
	@PostMapping( "/remove")
	@ResponseBody
	@RequiresPermissions("spotgrid:gridOrder:remove")
	public R remove( Long id){
		if(gridOrderService.remove(id)>0){
		return R.ok();
		}
		return R.error();
	}
	
	/**
	 * 删除
	 */
	@PostMapping( "/batchRemove")
	@ResponseBody
	@RequiresPermissions("spotgrid:gridOrder:batchRemove")
	public R remove(@RequestParam("ids[]") Long[] ids){
		gridOrderService.batchRemove(ids);
		return R.ok();
	}
	
}
