package com.bootdo.spotgrid.common.websocket.client;

import com.bootdo.spotgrid.common.websocket.callback.WebsocketCallback;
import com.bootdo.spotgrid.common.websocket.dto.BookTicker;

public class WebsocketBookTickerClient extends BaseWebsocketClient<BookTicker>{
    /**
     * @param symbols  trading pair separated by a coma.
     * @param callback Events handler.
     */
    public WebsocketBookTickerClient(String symbols, WebsocketCallback<BookTicker> callback) {
        super(symbols, "bookTicker", BookTicker.class, callback);
    }

    /**
     * @param symbols  Trading pair iterable.
     * @param callback Events handler.
     */
    public WebsocketBookTickerClient(Iterable<? extends CharSequence> symbols, WebsocketCallback<BookTicker> callback) {
        this(String.join(",", symbols), callback);
    }
}
