package com.bootdo.spotgrid.common.websocket.client;

import com.bootdo.spotgrid.common.websocket.configuration.WebsocketClientConfiguration;

/** A websocket client */
public interface WebsocketClient {
    /** Opens the stream. */
    void open();

    default void send(String message) {}

    /** Forces the closing of the stream. */
    void close();
    /**
     * Closes of the stream
     *
     * @param force force the closing?
     */
    void close(boolean force);

    /** @return The client configuration. */
    WebsocketClientConfiguration getConfiguration();
}
