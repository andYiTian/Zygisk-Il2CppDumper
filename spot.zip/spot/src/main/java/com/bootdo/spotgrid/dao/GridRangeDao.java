package com.bootdo.spotgrid.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bootdo.spotgrid.domain.RangeProDO;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface GridRangeDao extends BaseMapper<RangeProDO> {
}
