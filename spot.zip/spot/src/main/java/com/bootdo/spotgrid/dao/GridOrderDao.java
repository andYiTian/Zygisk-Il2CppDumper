package com.bootdo.spotgrid.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bootdo.spotgrid.domain.GridOrderDO;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * 网格订单
 * @author dongdong
 * @email 111
 * @date 2024-09-18 23:07:06
 */
@Mapper
public interface GridOrderDao extends BaseMapper<GridOrderDO> {

    @Select("SELECT (SELECT entrust_price FROM spot_grid_order where config_id = #{configId} and trend_type = 'SELL' and `status` = 'NEW' ORDER BY entrust_price asc limit 1) as sellLow,\n" +
            "(SELECT entrust_price FROM spot_grid_order where config_id = #{configId} and trend_type = 'SELL' and (`status` = 'NEW' or sell_load = 'shelve') ORDER BY entrust_price desc limit 1) as sellHigh")
    Map<String, BigDecimal> querySellPriceHeadLast(@Param("configId")Long configId);

}
