package com.bootdo.spotgrid.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bootdo.spotgrid.domain.GridConfigDO;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

/**
 * 现货网格配置
 * @author dongdogn
 * @email 1992lcg@163.com
 * @date 2024-09-14 15:19:00
 */
@Mapper
public interface GridConfigDao extends BaseMapper<GridConfigDO> {

}
