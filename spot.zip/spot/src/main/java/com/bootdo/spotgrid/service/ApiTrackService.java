package com.bootdo.spotgrid.service;

import com.bootdo.spotgrid.dao.ApiTrackDao;
import com.bootdo.spotgrid.domain.ApiTrackDO;
import reactor.util.function.Tuple3;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * 现货交易详情
 * 
 * @author dongdong
 * @email 111
 * @date 2024-09-18 23:07:06
 */
public interface ApiTrackService {
	
	ApiTrackDO get(Long id);
	
	int save(ApiTrackDO apiTrack);
	
	int update(ApiTrackDO apiTrack);
	
	int remove(Long id);
	
	int batchRemove(Long[] ids);

	Map<String,List<ApiTrackDO>> getByClient(List<String> clientIds);

	List<ApiTrackDO> getByClient(String clientId);

	ApiTrackDO getByClientNew(String clientId);

	ApiTrackDO getByClientCanceled(String clientId);

	ApiTrackDO getByClientFilled(String clientId);

	/**
	 *  未成交,已成交,均价
	 * @param clientId
	 * @return
	 */
	Tuple3<BigDecimal, BigDecimal, BigDecimal> getByCanceledNumber(String clientId);

	ApiTrackDao getApiTrackDao();
}
