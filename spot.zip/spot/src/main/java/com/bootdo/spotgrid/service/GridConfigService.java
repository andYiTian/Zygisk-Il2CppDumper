package com.bootdo.spotgrid.service;

import com.bootdo.spotgrid.dao.GridConfigDao;
import com.bootdo.spotgrid.domain.GridConfigDO;

import java.util.List;
import java.util.Map;

/**
 * 现货网格配置
 * 
 * @author dongdogn
 * @email 1992lcg@163.com
 * @date 2024-09-14 15:19:00
 */
public interface GridConfigService {
	
	GridConfigDO get(Long id);
	
	int save(GridConfigDO gridConfig);
	
	int update(GridConfigDO gridConfig);
	
	int remove(Long id);
	
	int batchRemove(Long[] ids);

	GridConfigDao getGridConfigDao();
}
