package com.bootdo.spotgrid.controller;

import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.bootdo.spotgrid.dao.AccountDao;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bootdo.spotgrid.domain.AccountDO;
import com.bootdo.spotgrid.service.AccountService;
import com.bootdo.common.utils.PageUtils;
import com.bootdo.common.utils.Query;
import com.bootdo.common.utils.R;

/**
 * 现货账号
 * 
 * @author dongdogn
 * @email 1992lcg@163.com
 * @date 2024-09-14 14:02:27
 */
 
@Controller
@RequestMapping("/spotgrid/account")
public class AccountController {
	@Autowired
	private AccountService accountService;

	@Autowired
	private AccountDao accountDao;
	
	@GetMapping()
	@RequiresPermissions("spotgrid:account:account")
	String Account(){
	    return "spotgrid/account/account";
	}
	
	@ResponseBody
	@GetMapping("/list")
	@RequiresPermissions("spotgrid:account:account")
	public PageUtils list(@RequestParam Map<String, Object> params){

		//查询列表数据
        Query query = new Query(params);
		IPage<AccountDO> page = accountDao.selectPage(Page.of(query.getPage(), query.getLimit()), null);
		return PageUtils.returnPage(page);
	}
	
	@GetMapping("/add")
	@RequiresPermissions("spotgrid:account:add")
	String add(){
	    return "spotgrid/account/add";
	}

	@GetMapping("/edit/{id}")
	@RequiresPermissions("spotgrid:account:edit")
	String edit(@PathVariable("id") Long id,Model model){
		AccountDO account = accountService.get(id);
		model.addAttribute("account", account);
	    return "spotgrid/account/edit";
	}
	
	/**
	 * 保存
	 */
	@ResponseBody
	@PostMapping("/save")
	@RequiresPermissions("spotgrid:account:add")
	public R save( AccountDO account){
		if(accountService.save(account)>0){
			return R.ok();
		}
		return R.error();
	}
	/**
	 * 修改
	 */
	@ResponseBody
	@RequestMapping("/update")
	@RequiresPermissions("spotgrid:account:edit")
	public R update( AccountDO account){
		accountService.update(account);
		return R.ok();
	}
	
	/**
	 * 删除
	 */
	@PostMapping( "/remove")
	@ResponseBody
	@RequiresPermissions("spotgrid:account:remove")
	public R remove( Long id){
		if(accountService.remove(id)>0){
		return R.ok();
		}
		return R.error();
	}
	
	/**
	 * 删除
	 */
	@PostMapping( "/batchRemove")
	@ResponseBody
	@RequiresPermissions("spotgrid:account:batchRemove")
	public R remove(@RequestParam("ids[]") Long[] ids){
		accountService.batchRemove(ids);
		return R.ok();
	}
	
}
