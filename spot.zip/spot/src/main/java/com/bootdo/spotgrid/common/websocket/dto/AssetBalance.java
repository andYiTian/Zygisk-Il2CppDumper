package com.bootdo.spotgrid.common.websocket.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AssetBalance {

   String asset;
   String free;
   String locked;

}
