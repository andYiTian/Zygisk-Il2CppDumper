package com.bootdo.spotgrid.service.account;

import com.binance.connector.client.SpotClient;
import com.binance.connector.client.impl.SpotClientImpl;
import com.binance.connector.client.impl.spot.Trade;
import com.bootdo.spotgrid.domain.AccountDO;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
@Slf4j
public class SpotAccountCheck {

    public boolean accountCheck(AccountDO account) {

        SpotClient client = new SpotClientImpl(account.getAccountKey(), account.getAccountSecret());
        Trade trade = client.createTrade();
        Map<String, Object> param = Maps.newLinkedHashMap();
        param.put("omitZeroBalances","true");

        String account1 = null;
        try {
            account1 = trade.account(param);
        } catch (Exception e) {
            return false;
        }

        JSONObject obj = new JSONObject(account1);
        return Boolean.TRUE.equals(obj.getBoolean("canTrade"));
    }
}
