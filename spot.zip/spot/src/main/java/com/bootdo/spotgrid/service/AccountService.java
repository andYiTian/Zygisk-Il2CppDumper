package com.bootdo.spotgrid.service;

import com.bootdo.spotgrid.dao.AccountDao;
import com.bootdo.spotgrid.domain.AccountDO;

import java.util.List;
import java.util.Map;

/**
 * 现货账号
 * 
 * @author dongdogn
 * @email 1992lcg@163.com
 * @date 2024-09-14 14:02:27
 */
public interface AccountService {
	
	AccountDO get(Long id);
	
	int save(AccountDO account);
	
	int update(AccountDO account);
	
	int remove(Long id);
	
	int batchRemove(Long[] ids);

	AccountDao getAccountDao();
}
