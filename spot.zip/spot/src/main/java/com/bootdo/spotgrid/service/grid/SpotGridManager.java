package com.bootdo.spotgrid.service.grid;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.binance.connector.client.SpotClient;
import com.binance.connector.client.enums.DefaultUrls;
import com.binance.connector.client.impl.SpotClientImpl;
import com.bootdo.common.utils.JSONUtils;
import com.bootdo.spotgrid.common.Constant;
import com.bootdo.spotgrid.common.CustomThreadFactory;
import com.bootdo.spotgrid.common.websocket.callback.WebsocketCallback;
import com.bootdo.spotgrid.common.websocket.callback.WebsocketCloseObject;
import com.bootdo.spotgrid.common.websocket.client.WebsocketUserDataClient;
import com.bootdo.spotgrid.common.websocket.dto.OrderTradeUpdate;
import com.bootdo.spotgrid.common.websocket.dto.UserDataUpdate;
import com.bootdo.spotgrid.common.websocket.dto.UserDataUpdateType;
import com.bootdo.spotgrid.common.websocket.exception.ApiException;
import com.bootdo.spotgrid.dao.GridRangeDao;
import com.bootdo.spotgrid.domain.AccountDO;
import com.bootdo.spotgrid.domain.ApiTrackDO;
import com.bootdo.spotgrid.domain.GridConfigDO;
import com.bootdo.spotgrid.domain.GridOrderDO;
import com.bootdo.spotgrid.service.AccountService;
import com.bootdo.spotgrid.service.ApiTrackService;
import com.bootdo.spotgrid.service.GridConfigService;
import com.bootdo.spotgrid.service.GridOrderService;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.common.util.concurrent.RateLimiter;

import lombok.Getter;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Response;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import javax.annotation.PreDestroy;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Service
@Slf4j
public class SpotGridManager {

    final ApiTrackService trackService;

    final GridOrderService orderService;

    final GridConfigService gridConfigService;

    final AccountService accountService;

    final GridRangeDao rangeDao;

    public SpotGridManager(ApiTrackService trackService, GridOrderService orderService, GridConfigService gridConfigService, AccountService accountService, GridRangeDao rangeDao) {
        this.trackService = trackService;
        this.orderService = orderService;
        this.gridConfigService = gridConfigService;
        this.accountService = accountService;
        this.rangeDao = rangeDao;
    }

    @Bean
    public CommandLineRunner init() {
        return args -> {

            loadGrid();

            TimeUnit.SECONDS.sleep(10);

            loadOrder();
        };
    }

    @PreDestroy
    public void destroy(){
        gridMap.values().forEach(SpotGridOrder::runningStop);
    }

    public SpotGridOrder getGridOrder(){
        return gridMap.values().stream().filter(SpotGridOrder::getRunning).findFirst().orElse(null);
    }
    
    public SpotGridOrder getGridOrder(Long configId) {
    	return gridMap.get(configId);
    }

    @SneakyThrows
    public synchronized void statusChange(Long configId,Integer status){

        log.info("configId:{} status:{}",configId,status);
        if(Constant.YES.equals(status)){


            if(gridMap.containsKey(configId)){
                SpotGridOrder spotGridOrder = gridMap.get(configId);
                if(spotGridOrder.getRunning()){
                    log.info("已运行");
                    return;
                }
                log.info("已停止-需要重新运行");
            }

            GridConfigDO gridConfigDO = gridConfigService.get(configId);
            accountListen(gridConfigDO.getAccountName());
            
            TimeUnit.SECONDS.sleep(3);

            ExecutorService executorService = Account_Run.get(gridConfigDO.getAccountName());
            log.info("orderThread-start:{}",configId);
            SpotGridOrder orderThread = new SpotGridOrder(configId,executorService,trackService,orderService,gridConfigService,rangeDao, accountService.getAccountDao());
            orderThread.start();
            gridMap.put(configId,orderThread);
        }

        if(Constant.NO.equals(status) && gridMap.containsKey(configId)){

            log.info("网格停止");
            SpotGridOrder spotGridOrder = gridMap.get(configId);
            spotGridOrder.runningStop();

        }

        if(Constant.STOP_CANCEL.equals(status) && gridMap.containsKey(configId)){

            log.info("网格撤单并 停止");
            SpotGridOrder spotGridOrder = gridMap.get(configId);
            spotGridOrder.cancelAllStop();
            
            
        }

    }



    private void loadGrid(){

        List<GridConfigDO> gridConfigs = gridConfigService.getGridConfigDao().selectList(Wrappers.lambdaQuery(GridConfigDO.class).eq(GridConfigDO::getStatus, Constant.YES));
        if(gridConfigs.isEmpty()){
            return;
        }
        List<String> collect = gridConfigs.stream().map(GridConfigDO::getAccountName).collect(Collectors.toList());
        List<AccountDO> accounts = accountService.getAccountDao().selectList(Wrappers.lambdaQuery(AccountDO.class).in(AccountDO::getAccountName, collect));

        accounts.forEach(this::accountListen);
    }
    ///// main
    public static final String URL_HTTP = DefaultUrls.PROD_URL;
    static final String URL_USER_WEBSOCKET = DefaultUrls.WS_URL+"/ws";
    static final String URL_ORDER_WEBSOCKET = DefaultUrls.WS_API_URL;

    ///// test
//    public static final String URL_HTTP = DefaultUrls.TESTNET_URL;
//    static final String URL_USER_WEBSOCKET = "wss://stream.testnet.binance.vision:9443/ws";
//    static final String URL_ORDER_WEBSOCKET = DefaultUrls.TESTNET_WS_API_URL;
    static final boolean ENV = true;

    final Map<Long,SpotGridOrder> gridMap = Maps.newHashMap();

    private void loadOrder(){

        List<GridConfigDO> gridConfigs = gridConfigService.getGridConfigDao().selectList(Wrappers.lambdaQuery(GridConfigDO.class).eq(GridConfigDO::getStatus, Constant.YES));

        for (GridConfigDO gridConfig : gridConfigs) {

            ExecutorService executorService = Account_Run.get(gridConfig.getAccountName());
            SpotGridOrder orderThread = new SpotGridOrder(gridConfig.getId(),executorService,trackService,orderService,gridConfigService,rangeDao, accountService.getAccountDao());
            orderThread.start();

            gridMap.put(gridConfig.getId(), orderThread);
        }

    }


    static final Map<String,ExecutorService> Account_Run = Maps.newConcurrentMap();
    static final Map<String,RateLimiter> Account_Create_Limiter = Maps.newConcurrentMap();
    static final Set<String> Account_Blacklist = Sets.newConcurrentHashSet();

    /**
     * 账号订单推送 创建 每10秒1次
     * @param account 现货账号
     */
    private void accountListen(AccountDO account){
        accountListen(account,null);
    }
    
    private void accountListen(String accountName){
    	
    	AccountDO selectOne = accountService.getAccountDao().selectOne(Wrappers.lambdaQuery(AccountDO.class).eq(AccountDO::getAccountName, accountName));
        accountListen(selectOne,null);
    }

    private void accountListen(AccountDO account,ExecutorService executorService){

        final String accountName = account.getAccountName();
        String syncKey = ("accountListen-" + accountName).intern();
        synchronized (syncKey){

        	if(Account_Run.containsKey(accountName)) {
        		return;
        	}

            if(!Account_Blacklist.contains(accountName) && Account_Create_Limiter.computeIfAbsent(accountName, (key) -> RateLimiter.create(0.1)).tryAcquire()){

                log.info("accountListen - tryAcquire:{}",accountName);

                SpotClient client = new SpotClientImpl(account.getAccountKey(), account.getAccountSecret(),URL_HTTP);

                UserDataListen callback = new UserDataListen(account, executorService);
                Account_Run.put(accountName,callback.getExecutorService());
                WebsocketUserDataClient userDataClient = new WebsocketUserDataClient(client.createUserData(), callback);
                userDataClient.getConfiguration().setBaseUrl(URL_USER_WEBSOCKET);
                userDataClient.open();
            }else{
                Account_Blacklist.add(accountName);
                log.error("accountListen - Account_Blacklist:{}",Account_Blacklist);
            }
        }

    }



    class UserDataListen implements WebsocketCallback<UserDataUpdate> {

        final AccountDO account;
        final String accountName;
        @Getter
        final ExecutorService executorService;

        UserDataListen(AccountDO account, ExecutorService executorService) {
            this.account = account;
            this.accountName = account.getAccountName();
            this.executorService = executorService == null ? Executors.newFixedThreadPool(1,CustomThreadFactory.instance) : executorService;
        }


        private void setMdc(){
            Constant.setMDC(account.getAccountName() + "-USDT");
        }

        @Override
        public void onMessage(UserDataUpdate message, String orgData) {

            if(UserDataUpdateType.ORDER_TRADE_UPDATE ==  message.getEventType()){
                executorService.execute(()->onMessageReal(message.getOrderTradeUpdateEvent(),orgData));
            }
        }

        private void onMessageReal(OrderTradeUpdate message, String orgData){

            setMdc();
            ApiTrackDO apiTrackDO = new ApiTrackDO();
            apiTrackDO.setApiName(accountName);
            apiTrackDO.setEventType(message.getEventType());
            apiTrackDO.setEventTime(message.getEventTime());
            apiTrackDO.setSymbol(message.getSymbol());
            apiTrackDO.setClientId(message.getNewClientOrderId());
            apiTrackDO.setSide(message.getSide());
            apiTrackDO.setType(message.getType());
            apiTrackDO.setTimeInForce(message.getTimeInForce().toString());
            apiTrackDO.setOrgiginalQuantity(message.getOriginalQuantity());
            apiTrackDO.setPrice(message.getPrice());
            apiTrackDO.setExecutionType(message.getExecutionType());
            apiTrackDO.setOrderStatus(message.getOrderStatus());
            apiTrackDO.setOrderRejectReason(message.getOrderRejectReason());
            apiTrackDO.setOrderId(message.getOrderId());
            apiTrackDO.setQuantityLastFilledTrade(message.getQuantityLastFilledTrade());
            apiTrackDO.setAccumulatedQuantity(message.getAccumulatedQuantity());
            apiTrackDO.setPriceOfLastFilledTrade(message.getPriceOfLastFilledTrade());
            apiTrackDO.setCommission(message.getCommission());
            apiTrackDO.setCommissionAsset(message.getCommissionAsset());
            apiTrackDO.setOrderTradeTime(message.getOrderTradeTime());
            apiTrackDO.setTradeId(message.getTradeId());
            apiTrackDO.setOrderBook(message.getOrderBook());
            apiTrackDO.setPending(message.getPending());
            apiTrackDO.setOrderCreationTime(message.getOrderCreationTime());
            apiTrackDO.setCumulativeQuoteQuantity(message.getCumulativeQuoteQuantity());
            apiTrackDO.setLastQuoteQuantity(message.getLastQuoteQuantity());
            apiTrackDO.setQuoteOrderQuantity(message.getQuoteOrderQuantity());
            apiTrackDO.setOrgData(orgData);

            executorService.execute(()->trackService.save(apiTrackDO));


            log.info("onMessageReal clientId:{} side:{} status:{} apiTrackDO:{}",apiTrackDO.getClientId(),apiTrackDO.getSide(),apiTrackDO.getOrderStatus(), JSONUtils.beanToJson(apiTrackDO));

            String orderStatus = apiTrackDO.getOrderStatus();
            GridOrderDO byClientId = orderService.getByClientId(apiTrackDO.getClientId());
            if(byClientId == null){
                return;
            }
            SpotGridOrder spotGridOrder = gridMap.get(byClientId.getConfigId());
            if(null == spotGridOrder){
                return;
            }
            if(Constant.orderNew(orderStatus)){

                spotGridOrder.userDataNew(apiTrackDO,byClientId);

            }else if(Constant.orderFilled(orderStatus)){

                spotGridOrder.userDataFilled(apiTrackDO,byClientId);

            }else if(Constant.orderCancel(orderStatus)){

                spotGridOrder.userDataCancel(apiTrackDO,byClientId);
            }
        }

        @Override
        public void onFailure(ApiException exception) {
            setMdc();
            log.error("onFailure",exception);
        }

        @Override
        public void onClosing(WebsocketCloseObject websocketCloseObject) {
            setMdc();
        }

        @Override
        public void onClosed(WebsocketCloseObject websocketCloseObject) {
            setMdc();
            log.info("onClosed hashCode:{}",this.hashCode());
            Account_Run.remove(account.getAccountName());
            accountListen(account,executorService);
        }

        @Override
        public void onOpen(Response response) {
            setMdc();
            log.info("onOpen hashCode:{}",this.hashCode());
        }
    }

}
