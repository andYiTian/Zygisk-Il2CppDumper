package com.bootdo.spotgrid.common.websocket.event;

import com.bootdo.spotgrid.common.websocket.callback.WebsocketInterceptorCallback;
import com.bootdo.spotgrid.common.websocket.client.WebsocketClient;
import com.bootdo.spotgrid.common.websocket.event.scheduled.ScheduledEvent;
import com.bootdo.spotgrid.common.websocket.event.scheduled.ScheduledTask;
import com.bootdo.spotgrid.common.websocket.event.scheduled.TimeoutEvent;
import com.bootdo.spotgrid.common.websocket.exception.ApiException;

import java.time.Duration;

/** The base class of every {@link WebsocketEventHandler} */
public abstract class BaseWebsocketEventHandler implements WebsocketEventHandler {
    /** 处理此事件处理程序的 websocket 客户端。 */
    protected final WebsocketClient websocketClient;
    /** 超时 ApiException。 */
    protected final ApiException timeoutException;
    /** 断开连接的 ApiException. */
    protected final ApiException disconnectedException;
    /** 内部计划事件。 */
    protected ScheduledEvent eventHandler;
    /** The used callback. */
    protected WebsocketInterceptorCallback<?> callback;

    /**
     * @param websocketClient Websocket client
     * @param callback        Callback
     */
    protected BaseWebsocketEventHandler(WebsocketClient websocketClient, WebsocketInterceptorCallback<?> callback) {
        this(websocketClient, callback, "Timeout", "Disconnected");
    }

    /**
     * @param websocketClient     Websocket client
     * @param callback            Callback
     * @param timeoutMessage      Timeout message
     * @param disconnectedMessage Disconnection message
     */
    protected BaseWebsocketEventHandler(WebsocketClient websocketClient, WebsocketInterceptorCallback<?> callback,
                                        String timeoutMessage,
                                        String disconnectedMessage) {
        this.websocketClient = websocketClient;
        timeoutException = new ApiException(-1007, timeoutMessage);
        disconnectedException = new ApiException(-1001, disconnectedMessage);
        this.callback = callback;
    }

    public void cancel() {
        if (eventHandler != null) {
            eventHandler.cancel();
        }
    }

    public void disconnect(Duration timeout) {
        ScheduledTask timeoutTask = () -> {
            callback.onFailure(disconnectedException);
            websocketClient.close(false);
        };
        eventHandler = new TimeoutEvent(timeout, timeoutTask);
    }
}
