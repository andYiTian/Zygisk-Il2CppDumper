package com.bootdo.spotgrid.common.websocket.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class Trade {
    @JsonProperty("e") String eventType;
    @JsonProperty("E") Long eventTime;
    @JsonProperty("s") String symbol;
    @JsonProperty("t") String tradeId;
    @JsonProperty("p") String price;
    @JsonProperty("q") String quantity;
    @JsonProperty("b") Long buyerOrderId;
    @JsonProperty("a")  Long sellerOrderId;
    @JsonProperty("T") Long tradeTime;
    @JsonProperty("m") Boolean buyerIsMarketMaker;
}
