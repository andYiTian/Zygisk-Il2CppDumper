package com.bootdo.spotgrid.common.websocket.serialization;

import com.bootdo.spotgrid.common.websocket.dto.AssetBalance;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;

import java.io.IOException;

/** {@link AssetBalance} deserializer */
public class AssetBalanceDeserializer extends JsonDeserializer<AssetBalance> {

    @Override
    public AssetBalance deserialize(JsonParser jp, DeserializationContext ctx) throws IOException {
        JsonNode n = jp.getCodec().readTree(jp);
        return new AssetBalance(n.get("a").asText(), n.get("f").asText(), n.get("l").asText());
    }
}
