package com.bootdo.spotgrid.common.websocket.callback;

import lombok.Data;

@Data
public class WebsocketCloseObject {

    /** The closing code. */
    int code;
    /** The closing reason. */
    String reason;

    public WebsocketCloseObject(int i, String clientForcedToClose) {
    }
}
