package com.bootdo.spotgrid.controller;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.bootdo.spotgrid.common.Constant;
import com.bootdo.spotgrid.dao.GridConfigDao;
import com.bootdo.spotgrid.dao.GridOrderDao;
import com.bootdo.spotgrid.service.grid.SpotGridManager;
import com.bootdo.spotgrid.service.grid.SpotGridOrder;
import com.google.common.collect.Maps;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bootdo.spotgrid.domain.GridConfigDO;
import com.bootdo.spotgrid.domain.GridOrderDO;
import com.bootdo.spotgrid.service.GridConfigService;
import com.bootdo.common.utils.PageUtils;
import com.bootdo.common.utils.Query;
import com.bootdo.common.utils.R;
import com.bootdo.common.utils.StringUtils;

/**
 * 现货网格配置
 * 
 * @author dongdogn
 * @email 1992lcg@163.com
 * @date 2024-09-14 15:19:00
 */
 
@Controller
@RequestMapping("/spotgrid/gridConfig")
public class GridConfigController {
	@Autowired
	private GridConfigService gridConfigService;

	@Autowired
	private SpotGridManager gridManager;

	@Autowired
	private GridConfigDao configDao;
	
	@Autowired
	private GridOrderDao orderDao;
	
	@GetMapping()
	@RequiresPermissions("spotgrid:gridConfig:gridConfig")
	String GridConfig(){
	    return "spotgrid/gridConfig/gridConfig";
	}
	
	@ResponseBody
	@GetMapping("/list")
	@RequiresPermissions("spotgrid:gridConfig:gridConfig")
	public PageUtils list(@RequestParam Map<String, Object> params){
		//查询列表数据
		Query query = new Query(params);
		IPage<GridConfigDO> page = configDao.selectPage(Page.of(query.getPage(), query.getLimit()),null);
		return PageUtils.returnPage(page);
	}
	
	@GetMapping("/add")
	@RequiresPermissions("spotgrid:gridConfig:add")
	String add(){
	    return "spotgrid/gridConfig/add";
	}

	@GetMapping("/edit/{id}")
	@RequiresPermissions("spotgrid:gridConfig:edit")
	String edit(@PathVariable("id") Long id,Model model){
		GridConfigDO gridConfig = gridConfigService.get(id);
		model.addAttribute("gridConfig", gridConfig);
	    return "spotgrid/gridConfig/edit";
	}
	
	@GetMapping("/detail/{id}")
	@RequiresPermissions("spotgrid:gridConfig:detail")
	String detail(@PathVariable("id") Long id,Model model) {
		GridConfigDO gridConfig = gridConfigService.get(id);
		model.addAttribute("gridConfig", gridConfig);
	    return "spotgrid/gridConfig/index-grid";
	}
	
	@ResponseBody
	@PostMapping("/orderList")
	@RequiresPermissions("spotgrid:gridConfig:detail")
	public Map<String,Object> orderList(@RequestParam Map<String, Object> params) {
		
		String type = params.get("type").toString();
		Long configId = Long.valueOf(params.get("configId").toString());
		GridConfigDO selectById = configDao.selectById(configId);
		
		
		Map<String,Object> result = Maps.newHashMap();
		
		if("FILLED".equals(type)) {
			
			String from = params.get("from").toString();
			String to = params.get("to").toString();
			
			LocalDateTime start = LocalDateTime.ofInstant(Instant.ofEpochMilli(Long.valueOf(from)), ZoneId.systemDefault());
			LocalDateTime end = LocalDateTime.ofInstant(Instant.ofEpochMilli(Long.valueOf(to)), ZoneId.systemDefault());
			
			 List<GridOrderDO> selectList = orderDao.selectList(Wrappers.lambdaQuery(GridOrderDO.class)
					.eq(GridOrderDO::getConfigId, configId)
					.in(GridOrderDO::getStatus, Constant.Order_Filled)
					.between(GridOrderDO::getFilledTime, start, end)
					.orderByDesc(GridOrderDO::getFilledTime));
			
			 result.put("filled", selectList);
			 
		}
		if("NEW".equals(type)) {
			
			
			List<GridOrderDO> selectList = orderDao.selectList(Wrappers.lambdaQuery(GridOrderDO.class)
					.eq(GridOrderDO::getConfigId, configId)
					.in(GridOrderDO::getStatus, Constant.Order_Local,Constant.Order_NEW));
			result.put("new", selectList);
			
			if(Constant.YES.equals(selectById.getCancelType())) {
				
				List<GridOrderDO> shelve = orderDao.selectList(Wrappers.lambdaQuery(GridOrderDO.class)
						.eq(GridOrderDO::getConfigId, configId)
						.eq(GridOrderDO::getSellLoad, Constant.Order_Load));
				result.put("shelve", shelve);
			}
			
			
			Object to = params.get("to");
			LocalDateTime end = null;
			if(to != null && StringUtils.isNotBlank(to.toString())) {
				
				end = LocalDateTime.ofInstant(Instant.ofEpochMilli(Long.valueOf(to.toString())), ZoneId.systemDefault());
			}
			
			List<GridOrderDO> selectList2 = orderDao.selectList(Wrappers.lambdaQuery(GridOrderDO.class)
					.eq(GridOrderDO::getConfigId, configId)
					.in(GridOrderDO::getStatus, Constant.Order_Filled)
					.gt(end != null,GridOrderDO::getFilledTime,end)
					.orderByDesc(GridOrderDO::getFilledTime));
			
			result.put("newFilled", selectList2);
		
			 SpotGridOrder gridOrder = gridManager.getGridOrder(configId);
			 if(gridOrder != null) {
				 result.put("buy",gridOrder.getSellPriceLine().stream().map(SpotGridOrder.PriceLine::getBuyOrder).collect(Collectors.toList()));
				 result.put("configStatus", gridOrder.getConfigStatus());
			 }
		}
		return result;
	}

	
	
	
	/**
	 * 保存
	 */
	@ResponseBody
	@PostMapping("/save")
	@RequiresPermissions("spotgrid:gridConfig:add")
	public R save( GridConfigDO gridConfig){
		if(gridConfigService.save(gridConfig)>0){
			return R.ok();
		}
		return R.error();
	}
	/**
	 * 修改
	 */
	@ResponseBody
	@RequestMapping("/update")
	@RequiresPermissions("spotgrid:gridConfig:edit")
	public R update( GridConfigDO gridConfig){

		gridManager.statusChange(gridConfig.getId(),gridConfig.getStatus());

		if(Constant.STOP_CANCEL.equals(gridConfig.getStatus())){
			gridConfig.setStatus(Constant.NO);
		}
		gridConfigService.update(gridConfig);
		return R.ok();
	}
	
	/**
	 * 删除
	 */
	@PostMapping( "/remove")
	@ResponseBody
	@RequiresPermissions("spotgrid:gridConfig:remove")
	public R remove( Long id){
		if(gridConfigService.remove(id)>0){
		return R.ok();
		}
		return R.error();
	}
	
	/**
	 * 删除
	 */
	@PostMapping( "/batchRemove")
	@ResponseBody
	@RequiresPermissions("spotgrid:gridConfig:batchRemove")
	public R remove(@RequestParam("ids[]") Long[] ids){
		gridConfigService.batchRemove(ids);
		return R.ok();
	}
	
}
