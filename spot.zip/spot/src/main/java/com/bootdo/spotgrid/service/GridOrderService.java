package com.bootdo.spotgrid.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.bootdo.spotgrid.dao.GridOrderDao;
import com.bootdo.spotgrid.domain.GridConfigDO;
import com.bootdo.spotgrid.domain.GridOrderDO;
import com.bootdo.spotgrid.service.grid.SIDE;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * 网格订单
 * 
 * @author dongdong
 * @email 111
 * @date 2024-09-18 23:07:06
 */
public interface GridOrderService {
	
	GridOrderDO get(Long id);

	GridOrderDO getByClientId(String clientId);

	List<GridOrderDO> getOrdersByWait(GridConfigDO configDO);

	int save(GridOrderDO gridOrder);
	
	int update(GridOrderDO gridOrder);
	
	int remove(Long id);
	
	int batchRemove(Long[] ids);

	GridOrderDO getByTypePrice(GridConfigDO configDO,BigDecimal price, SIDE side);

    List<GridOrderDO> getLoad(GridConfigDO configDO);

	List<GridOrderDO> batchBuyByIds(List<Long> ids);


	GridOrderDao getGridOrderDao();
}
