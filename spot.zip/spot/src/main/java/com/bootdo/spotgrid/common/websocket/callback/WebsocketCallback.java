package com.bootdo.spotgrid.common.websocket.callback;

import com.bootdo.spotgrid.common.websocket.exception.ApiException;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Websocket client stream events handler */
@FunctionalInterface
public interface WebsocketCallback<T> {

    Logger log = LoggerFactory.getLogger(WebsocketCallback.class);

    /**
     * Triggered when the server sends data
     *
     * @param message Server message.
     */
    void onMessage(T message,String orgData);

    /**
     * Triggered when the connection fails
     *
     * @param exception Exception containing the API code and message error.
     */
    default void onFailure(ApiException exception) {
        log.error("WebsocketCallback default- onFailure", exception);
    }

    /**
     * Triggered when the connection is closing
     *
     * @param websocketCloseObject Websocket closing code and reason container.
     */
    default void onClosing(WebsocketCloseObject websocketCloseObject) {
        log.info("WebsocketCallback default- onClosing:{}", websocketCloseObject.getReason());
    }

    /**
     * Triggered when the connection is closed
     *
     * @param websocketCloseObject Websocket closing code and reason container.
     */
    default void onClosed(WebsocketCloseObject websocketCloseObject) {
        log.info("WebsocketCallback default- onClosed:{}", websocketCloseObject.getReason());
    }

    /**
     * Triggered when the connection is opened
     *
     * @param response API open response.
     */
    default void onOpen(Response response) {
        log.info("WebsocketCallback default- onOpen:{}", response);
    }
}
