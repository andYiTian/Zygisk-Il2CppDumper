package com.bootdo.spotgrid.vo;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * 配对 盈利状态
 */

@Getter
@Setter
public class ConfigStatus {

    /** 配对次数 */
    private volatile int pairSize = 0;

    /** 配对利润*/
    private volatile BigDecimal pairProfit;

    private volatile int lossSize = 0;
    /** 止损后利润 */
    private volatile BigDecimal lossProfit;

    /** 实际利润 */
    private volatile BigDecimal totalProfit;

    private ConfigInfo configInfo;
       
}

