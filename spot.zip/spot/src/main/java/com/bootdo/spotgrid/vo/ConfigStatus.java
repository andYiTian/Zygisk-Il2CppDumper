package com.bootdo.spotgrid.vo;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * 配对 盈利状态
 */

@Getter
@Setter
public class ConfigStatus {

    /** 配对次数 */
    private int pairSize;

    /** 配对利润*/
    private BigDecimal pairProfit;

    /** 止损后利润 */
    private BigDecimal lossProfit;

    /** 实际利润 */
    private BigDecimal totalProfit;

    private ConfigInfo configInfo;
       
}

