package com.bootdo.spotgrid.vo;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ConfigInfo {

    
    /** 区间 标位*/
    private int rangeIndex = 0 ; 
    
    /** 当前区间 - 开始价格*/
    private BigDecimal rangeStart = BigDecimal.ZERO;
    
    /** 当前区间 - 结束价格*/
    private BigDecimal rangeEnd = BigDecimal.ZERO;
    
    /** 起始价格*/
    private BigDecimal startPrice = BigDecimal.ZERO;
    
    /**亏损金额*/
    private BigDecimal firstAmt = BigDecimal.ZERO;
    /**亏损跌幅*/
    private BigDecimal firstFall = BigDecimal.ZERO;
    /**可补金额*/
    private BigDecimal compensateAmt = BigDecimal.ZERO;
    
}
