package com.bootdo.common.config;

import lombok.extern.slf4j.Slf4j;

import java.io.IOException;

@Slf4j
public class OnlyProcess {

    static final FileLockManager LOCK = new FileLockManager(System.getProperty("user.dir") + "\\lock\\spot-only.lock");

    public static boolean check() {

        boolean lock2 = false;
        try {
            lock2 = LOCK.Lock();
            System.out.println("lock-file: "+ lock2);
        } catch (IOException e) {
            log.error("FileLockManager.Lock - ",e);
        }

        if(lock2) {
            Runtime.getRuntime().addShutdownHook(new Thread(()->{
                try {
                    LOCK.unLock();
                    System.out.println("unlock-file: "+ LOCK);
                } catch (IOException e) {

                }
            }));
        }else{

            System.out.println("lock-exit");
            Runtime.getRuntime().exit(0);
        }

        return lock2;
    }


}
