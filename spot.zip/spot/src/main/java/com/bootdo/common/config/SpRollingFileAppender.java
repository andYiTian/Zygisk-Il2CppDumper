package com.bootdo.common.config;

import java.io.OutputStream;
import java.util.Timer;
import java.util.TimerTask;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.rolling.RollingFileAppender;
import ch.qos.logback.core.status.ErrorStatus;

public class SpRollingFileAppender extends RollingFileAppender<ILoggingEvent> {

    private long idleTimeForceFlush = 0;

    private volatile long lastFlushTime = System.currentTimeMillis();

    private static final  Timer TIMER = new Timer(true);;

    public long getIdleTimeForceFlush() {
        return idleTimeForceFlush;
    }

    public void setIdleTimeForceFlush(long idleTimeForceFlush) {
        this.idleTimeForceFlush = idleTimeForceFlush;
    }

    @Override
    public void start() {
        super.start();
        if (needForceFlush()) {
            TIMER.schedule(new FlushTask(), 1000L, idleTimeForceFlush);
        }
    }

    @Override
    protected void subAppend(ILoggingEvent event) {
        super.subAppend(event);
        if (needForceFlush()) {
            lastFlushTime = System.currentTimeMillis();
        }
    }

    private boolean needForceFlush() {
        return !isImmediateFlush() && idleTimeForceFlush > 0;
    }

    private void flush() {
        lock.lock();
        try {
            OutputStream outputStream = getOutputStream();
            if (outputStream != null) {
                outputStream.flush();
            }
        } catch (Throwable e) {
            addStatus(new ErrorStatus("flush IO failure in timer task.", this, e));
        } finally {
            lock.unlock();
        }
    }

    private class FlushTask extends TimerTask {

        @Override
        public void run() {
            if (System.currentTimeMillis() - lastFlushTime > idleTimeForceFlush) {
                flush();
            }
        }
    }
}
