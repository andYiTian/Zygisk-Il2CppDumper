$().ready(function() {
	validateRule();
});

$.validator.setDefaults({
	submitHandler : function() {
		save();
	}
});

let editor = null;

function createJSONEditor(){

	const container = document.getElementById('otherConfigJson');
	//const options = {search: false,mode: 'from',history:false,mainMenuBar:false,navigationBar:false};
	const options = {mode: 'form',mainMenuBar:false,onBlur:function(type,target){

			document.getElementById('config').value = editor.getText();
		}};
	editor = new JSONEditor(container,options);

	editor.set({headOrderFall:'0.1',compensate:'0.5'});
	editor.focus();
}
createJSONEditor();

function save() {
	let form = $('#signupForm').serialize();
	$.ajax({
		cache : true,
		type : "POST",
		url : "/spotgrid/gridConfig/save",
		data : form,// 你的formid
		async : false,
		error : function(request) {
			parent.layer.alert("Connection error");
		},
		success : function(data) {
			if (data.code == 0) {
				parent.layer.msg("操作成功");
				parent.reLoad();
				var index = parent.layer.getFrameIndex(window.name); // 获取窗口索引
				parent.layer.close(index);

			} else {
				parent.layer.alert(data.msg)
			}

		}
	});

}
function validateRule() {
	var icon = "<i class='fa fa-times-circle'></i> ";
	$("#signupForm").validate({
		rules : {
			name : {
				required : true
			}
		},
		messages : {
			name : {
				required : icon + "请输入姓名"
			}
		}
	})
}