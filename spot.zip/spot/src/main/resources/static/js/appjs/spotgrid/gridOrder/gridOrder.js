
var prefix = "/spotgrid/gridOrder"
$(function() {
	load();
	setInterval(load, 5000);
});

function load() {

	$.ajax({
		url: prefix + "/getPendingOrder",
		type : 'post',
		success : function(result) {

				infoView(result['configStatus']);
				pendingTable('sell',result['sell']);
				pendingTable('buy',result['buy']);

		}
	})

}

function infoView(configStatus){
	let info = `配对：${configStatus.pairSize}  利润:${configStatus.pairProfit}`;
	$("#info").text(info);
}

function pendingTable(side,sellOrder){

	let sell = document.getElementById(side);
	sell.children[0].remove()

	let domOrder = "";
	for(let e of sellOrder){
		domOrder = domOrder + `<tr><td>${side} ${e.entrustPrice}  ${e.entrustNumber}</td></tr>`;
	}

	$('#'+side).html(`<tbody>${domOrder}</tbody>`);
}



function reLoad() {

}